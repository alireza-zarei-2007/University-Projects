#include <string>
#include <sstream>
#include <iostream>
#include "../include/CommandHandler.hpp"

using namespace std;

CommandHandler::CommandHandler(StockMarket& m, OrderBook& o): market(m), book(o){}

void CommandHandler::processCommand(string line){
    stringstream ss(line);

    string cmd;
    ss >> cmd;

    if(cmd == "register"){
        string username;
        int credit;

        ss >> username >> credit;
        market.checkUserExist(username, credit);
    }

    if(cmd == "sell_order"){
        string username;
        int shares_count;
        string company_name;
        int suggested_price;

        ss >> username >> shares_count >> company_name >> suggested_price;

        ShareHolder* target_holder = market.getShareHolder(username);
        if(!target_holder->hasEnoughShares(company_name, shares_count)){
            cout << "Insufficient free shares." << endl;
            return;
        }

        Company* target_company = market.getCompany(company_name);
        if(target_company->hasBuyOrder(username)){
            cout << username << " already has a buy order queued for " << company_name << '.' << endl;
            return;
        }
        
        book.addNewOrder(username, shares_count, company_name, suggested_price, SELL);

        book.processOrderMatch(&market, company_name, suggested_price, shares_count, target_company, target_holder, SELL);
    }

    if(cmd == "buy_order"){
        string username;
        int shares_count;
        string company_name;
        int suggested_price;

        ss >> username >> shares_count >> company_name >> suggested_price;

        ShareHolder* target_holder = market.getShareHolder(username);
        int money_of_shares = shares_count * suggested_price;
        if(!target_holder->hasEnoughMoney(money_of_shares)){
            cout << "Insufficient free credit." << endl;
            return;
        }

        Company* target_company = market.getCompany(company_name);
        if(target_company->hasSellOrder(username)){
            cout << username << " already has a sell order queued for " << company_name << '.' << endl;
            return;
        }

        book.addNewOrder(username, shares_count, company_name, suggested_price, BUY);

        book.processOrderMatch(&market, company_name, suggested_price, shares_count, target_company, target_holder, BUY);
    }

    if(cmd == "cancel_order"){
        int order_id;

        ss >> order_id;

        book.findOrderAndCanceling(&market, order_id);
    }

    if(cmd == "report_portfolio"){
        string username;

        ss >> username;

        ShareHolder* _target_holder = market.getShareHolder(username);
        if(_target_holder == nullptr){
            cout << username << " not found." << endl;
            return;
        }

        _target_holder->reportPortfolio(&market);
    }

    if(cmd == "report_company"){
        string company_name;

        ss >> company_name;

        Company* _target_company = market.getCompany(company_name);
        if(_target_company == nullptr){
            cout << company_name << " not found." << endl;
            return;
        }

        _target_company->report();
    }
}

void CommandHandler::run(){
    string line;

    while(getline(cin, line)){
        processCommand(line);
    }
}