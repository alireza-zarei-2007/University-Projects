#include <vector>
#include <string>
#include <fstream>
#include <sstream>
#include <iostream>
#include "../include/StockMarket.hpp"

const int NUM_OF_FEATURE_COMPANY = 2;
const int NUM_OF_FEATURE_SHAREHOLDER = 2;

using namespace std;

void StockMarket::addFirstCompanies(string company_name, int share_price){
    Company* new_company = new Company(company_name, share_price);
    companies.push_back(new_company);
}

void StockMarket::addFirstShareholders(string username, int credit, vector<string> name_of_company_shares, vector<int> num_of_shares){
    ShareHolder* new_shareholder = new ShareHolder(username, credit, name_of_company_shares, num_of_shares);
    share_holders.push_back(new_shareholder);
}

void StockMarket::openReadCSVCompany(string C_file_name){
    ifstream file(C_file_name);

    string line;
    getline(file, line);

    while(getline(file, line)){
        stringstream ss(line);
        string company_name;
        int share_price;
        string cell;

        for(int i=0; i<NUM_OF_FEATURE_COMPANY; i++){
            getline(ss, cell, ',');
            if(i == 0) company_name = cell;
            if(i == 1) share_price = stoi(cell);
        }
        addFirstCompanies(company_name, share_price);
    }
}

void StockMarket::openReadCSVshareHolder(string S_data_file_name){
    ifstream file(S_data_file_name);

    string line;
    getline(file, line);

    while(getline(file, line)){
        string username;
        int credit;
        string cell;
        vector<string> name_of_company_shares;
        vector<int> num_of_shares;

        stringstream ss(line);

        for(int i=0; i<NUM_OF_FEATURE_SHAREHOLDER; i++){
            getline(ss,cell,',');
            if(i==0) username = cell;
            if(i==1) credit = stoi(cell);
        }
        while(getline(ss,cell,';')){
            string company_name;
            int num_of_share;
            int colon_pos = cell.find(':');
            company_name = cell.substr(0, colon_pos);
            num_of_share = stoi(cell.substr(colon_pos + 1));

            name_of_company_shares.push_back(company_name);
            num_of_shares.push_back(num_of_share);
        }
        addFirstShareholders(username, credit, name_of_company_shares, num_of_shares);

    }
}

void StockMarket::addNewShareHolder(string username, int credit){
    ShareHolder* new_shareholder = new ShareHolder(username, credit);
    share_holders.push_back(new_shareholder);
}

bool StockMarket::isUserExist(string u_name){
    for(ShareHolder* holder: share_holders){
        if(holder->isThisMyName(u_name)) return true;
    }
    return false;
}

void StockMarket::checkUserExist(string u_name, int credit){
    if(isUserExist(u_name)){
        cout << u_name << " already exists." << endl;
    }else{
        addNewShareHolder(u_name, credit);
        cout << u_name << " registered successfully." << endl;
    }
}

ShareHolder* StockMarket::getShareHolder(string u_name){
    for(ShareHolder* holder: share_holders){
        if(holder->isThisMyName(u_name)) return holder;
    }
    return nullptr;
}

Company* StockMarket::getCompany(string company_name){
    for(Company* company:companies){
        if(company->isThisMyName(company_name)) return company;
    }
    return nullptr;
}



