#include <string>
#include "../include/Order.hpp"
#include "../include/enum.hpp"


using namespace std;
using namespace orderstatus;
using namespace ordertype;

Order::Order(string _username, int _shares_count, string _company_name, int _suggested_price, type _type,  int _order_id):order_id(_order_id)
            , username(_username), shares_count(_shares_count), company_name(_company_name)
            , Suggested_price(_suggested_price), my_type(_type), my_status(PENDING){}

string Order::getUsername(){return username;}

status Order::getStatus(){return my_status;}

int Order::getSharesCount(){return shares_count;}

int Order::getSuggestedPrice(){return Suggested_price;}

int Order::getId(){return order_id;}

void Order::matched(){my_status = MATCHED;}

void Order::cancelled(){my_status == CANCELLED;}

string Order::getCompanyName(){return company_name;}

type Order::getType(){return my_type;}