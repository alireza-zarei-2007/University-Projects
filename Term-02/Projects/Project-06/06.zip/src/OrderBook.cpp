#include <vector>
#include <string>
#include <iostream>
#include "../include/OrderBook.hpp"
#include "../include/enum.hpp"

using namespace ordertype;


void OrderBook::addNewOrder(string _username, int _shares_count, string _company_name, int _suggested_price, type _type){
    int _order_id = orders.size() + 1;
    Order* new_order = new Order(_username, _shares_count, _company_name, _suggested_price, _type, _order_id);
    orders.push_back(new_order);
}

Order* OrderBook::findOrderFromBuyQueue(int _suggested_price, int _shares_count, Company* _target_company){
    Order* _order_to_match = _target_company->getOrderToMatchFromBuyQueue(_suggested_price,_shares_count);
    return _order_to_match;
}

Order* OrderBook::findOrderFromSellQueue(int _suggested_price, int _shares_count, Company* _target_company){
    Order* _order_to_match = _target_company->getOrderToMatchFromSellQueue(_suggested_price,_shares_count);
    return _order_to_match;
}

void OrderBook::addToSellQueue(Order* _main_order, Company* _target_company){
    _target_company->addOrderToSellQueue(_main_order);
}

void OrderBook::addToBuyQueue(Order* _main_order, Company* _target_company){
    _target_company->addOrderToBuyQueue(_main_order);
}

void OrderBook::processOrderMatch(StockMarket* market, string _company_name, int _suggested_price, int _shares_count, Company* _target_company
                                , ShareHolder* _target_holder, type _my_type){
    
    if(_my_type == SELL){
        _target_holder->blockShare(_company_name, _shares_count);
        Order* order_to_match = findOrderFromBuyQueue(_suggested_price, _shares_count, _target_company);
        Order* main_order = orders[orders.size() - 1];
        addToSellQueue(main_order, _target_company);
        
        if(order_to_match != nullptr){
            string buyer_holder_name = order_to_match->getUsername();
            ShareHolder* buyer_holder = market->getShareHolder(buyer_holder_name);
            match(buyer_holder, _target_holder, order_to_match, main_order, _target_company, _suggested_price, _shares_count, _company_name);
            cout << "Order " << main_order->getId() << " matched with order " << order_to_match->getId() << '.' << endl;
        }else{
            cout << "Order " << main_order->getId() << " queued." << endl;
        }
    }
    if(_my_type == BUY){
        int money_of_shares = _shares_count * _suggested_price;
        _target_holder->blockMoney(money_of_shares);
        Order* order_to_match = findOrderFromSellQueue(_suggested_price, _shares_count, _target_company);
        Order* main_order = orders[orders.size() - 1];
        addToBuyQueue(main_order, _target_company);

        if(order_to_match != nullptr){
            string seller_holder_name = order_to_match->getUsername();
            ShareHolder* seller_holder = market->getShareHolder(seller_holder_name);
            match(_target_holder, seller_holder, main_order, order_to_match, _target_company, _suggested_price, _shares_count, _company_name);
            cout << "Order " << main_order->getId() << " matched with order " << order_to_match->getId() << '.' << endl;
        }else{
            cout << "Order " << main_order->getId() << " queued." << endl;
        }
    }
}

void OrderBook::transferMoneyShare(ShareHolder* _buyer_holder, ShareHolder* _seller_holder, int _suggested_price, int _shares_count
                                    , string _company_name){

    int money_transfer = _shares_count * _suggested_price;
    _buyer_holder->updatePortfolioAfterBuy(_company_name, money_transfer, _shares_count);
    _seller_holder->updatePortfolioAfterSell(_company_name, money_transfer, _shares_count);
}

void OrderBook::match(ShareHolder* _buyer_holder, ShareHolder* _seller_holder, Order* _buy_order, Order* _sell_order, Company* _target_company
                , int _suggested_price, int _shares_count, string _company_name){
    
    transferMoneyShare(_buyer_holder, _seller_holder, _suggested_price, _shares_count, _company_name);
    _buy_order->matched();
    _sell_order->matched();
    _target_company->removeOrdersFromQueues(_buy_order, _sell_order);
    _target_company->setNewSharePrice(_suggested_price);
}

void OrderBook::findOrderAndCanceling(StockMarket* market, int _order_id){
    Order* _target_order;
    bool has_order = false;
    for(Order* order: orders){
        if(order->getId() == _order_id){
            has_order = true;
            _target_order = order;
        }
    }
    if((!has_order) || (_target_order->getStatus() == CANCELLED) || (_target_order->getStatus() == MATCHED)){
        cout << "Order " << _order_id << " not found." << endl;
        return;
    }

    string order_company_name = _target_order->getCompanyName();
    Company* _target_compnay = market->getCompany(order_company_name);
    type order_type = _target_order->getType();

    string order_username = _target_order->getUsername();
    ShareHolder* _target_holder = market->getShareHolder(order_username);

    int suggested_price = _target_order->getSuggestedPrice();
    int shares_count = _target_order->getSharesCount();
    int money_transfer = shares_count * suggested_price;
    if(order_type == BUY){
        _target_holder->freeMoney(money_transfer);
    }else if(order_type == SELL){
        _target_holder->freeShare(order_company_name, shares_count);
    }

    _target_order->cancelled();
    _target_compnay->removeOrderForCanceling(_target_order, order_type);
    cout << "Canceled order " << _order_id << '.' << endl;
}