#include <string>
#include <algorithm>
#include <iostream>
#include <vector>
#include "../include/Company.hpp"

using namespace std;
using namespace orderstatus;

Company::Company(string n, int price): share_name(n), share_price(price){}

int Company::getPrice(){
    return share_price;
}

bool Company::isThisMyName(string company_name){
    return company_name == share_name;
}

bool Company::hasBuyOrder(string u_name){
    for(Order* order: buy_queue){
        if((order->getUsername() == u_name) && (order->getStatus() == PENDING)){
            return true;
        }
    }
    return false;
}

bool Company::hasSellOrder(string u_name){
    for(Order* order: sell_queue){
        if((order->getUsername() == u_name) && (order->getStatus() == PENDING)){
            return true;
        }
    }
    return false;
}

Order* Company::getOrderToMatchFromBuyQueue(int _suggested_price, int _shares_count){
    for(int i=0; i<buy_queue.size(); i++){
        if((buy_queue[i]->getSuggestedPrice() == _suggested_price) && (buy_queue[i]->getSharesCount() == _shares_count)){
            return buy_queue[i];
        }
    }
    return nullptr;
}

Order* Company::getOrderToMatchFromSellQueue(int _suggested_price, int _shares_count){
    for(int i=0; i<sell_queue.size(); i++){
        if((sell_queue[i]->getSuggestedPrice() == _suggested_price) && (sell_queue[i]->getSharesCount() == _shares_count)){
            return sell_queue[i];
        }
    }
    return nullptr;
}

void Company::addOrderToSellQueue(Order* _order){
    sell_queue.push_back(_order);
}

void Company::addOrderToBuyQueue(Order* _order){
    buy_queue.push_back(_order);
}

void Company::removeOrdersFromQueues(Order* _buy_order, Order* _sell_order){
    auto it_buy = find(buy_queue.begin(), buy_queue.end(), _buy_order);
    if(it_buy != buy_queue.end()){
        buy_queue.erase(it_buy);
    }

    auto it_sell = find(sell_queue.begin(), sell_queue.end(), _sell_order);
    if(it_sell != sell_queue.end()){
        sell_queue.erase(it_sell);
    }
    
}

void Company::removeOrderForCanceling(Order* _target_order, type order_type){
    if(order_type == BUY){
        auto it_buy = find(buy_queue.begin(), buy_queue.end(), _target_order);
        if(it_buy != buy_queue.end()){
            buy_queue.erase(it_buy);
        }
    }
    if(order_type == SELL){
        auto it_sell = find(sell_queue.begin(), sell_queue.end(), _target_order);
        if(it_sell != sell_queue.end()){
            sell_queue.erase(it_sell);
        }
    }
}

void Company::setNewSharePrice(int new_share_price){share_price = new_share_price;}

void Company::report(){
    cout << share_name << " report" << endl;
    cout << "Current price: $" << share_price << endl;
    vector<Order*> buy_queue_sorted  = buy_queue;
    vector<Order*> sell_queue_sorted = sell_queue;
    sort(buy_queue_sorted.begin(), buy_queue_sorted.end(), 
        [](Order* a, Order* b){
            if(a->getSuggestedPrice() != b->getSuggestedPrice()){
                return a->getSuggestedPrice() > b->getSuggestedPrice();
            }
            return a->getId() < b->getId();
        });

    sort(sell_queue_sorted.begin(), sell_queue_sorted.end(), 
        [](Order* a, Order* b){
            if(a->getSuggestedPrice() != b->getSuggestedPrice()){
                return a->getSuggestedPrice() < b->getSuggestedPrice();
            }
            return a->getId() < b->getId();
        });

    cout << "sell queue:" << endl;
    if(sell_queue_sorted.size() == 0){
        cout << "(empty)" << endl;
    }else{
        for(int i=0; i<sell_queue_sorted.size(); i++){
            cout << i+1 << ". Shares: " << sell_queue_sorted[i]->getSharesCount()
                    << " - Price: $" << sell_queue_sorted[i]->getSuggestedPrice()
                    << " - ID: " << sell_queue_sorted[i]->getId() << endl;
        }
    }
    
    cout << "buy queue:" << endl;
    if(buy_queue_sorted.size() == 0){
        cout << "(empty)" << endl;
    }else{
        for(int i=0; i<buy_queue_sorted.size(); i++){
            cout << i+1 << ". Shares: " << buy_queue_sorted[i]->getSharesCount()
                    << " - Price: $" << buy_queue_sorted[i]->getSuggestedPrice()
                    << " - ID: " << buy_queue_sorted[i]->getId() << endl;
        }
    }
    
}