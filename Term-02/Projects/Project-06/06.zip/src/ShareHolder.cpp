#include <vector>
#include <string>
#include <algorithm>
#include <iostream>
#include <map>
#include "../include/ShareHolder.hpp"

using namespace std;

ShareHolder::ShareHolder(string u_name, int credit, vector<string> name_of_company_shares
    , vector<int> num_of_shares) 
    : username(u_name), free_money(credit), blocked_money(0){
    
    int num_of_company = name_of_company_shares.size();

    for(int i=0; i<num_of_company; i++){
        free_shares[name_of_company_shares[i]] = num_of_shares[i];
    }

}

ShareHolder::ShareHolder(string u_name, int credit): username(u_name), free_money(credit), blocked_money(0){}

bool ShareHolder::isThisMyName(string u_name){
    return u_name == username;
}

int ShareHolder::getMySharesCount(string company_name){
    auto it = free_shares.find(company_name);
    if(it == free_shares.end()){
        return 0;
    }else{
        return it->second;
    }
}

bool ShareHolder::hasEnoughShares(string company_name, int shares_count){
    int my_shares_count = getMySharesCount(company_name);
    return (my_shares_count >= shares_count);
}

bool ShareHolder::hasEnoughMoney(int _money_of_shares){
    return (free_money >= _money_of_shares);
}



void ShareHolder::blockShare(string _company_name, int _shares_count){
    auto it = free_shares.find(_company_name);
    it->second -= _shares_count;
    if(it->second == 0){
        free_shares.erase(it);
    }
    blocked_shares[_company_name] += _shares_count;
}

void ShareHolder::freeShare(string _company_name, int _shares_count){
    auto it = blocked_shares.find(_company_name);
    it->second -= _shares_count;
    if(it->second == 0){
        free_shares.erase(it);
    }
    free_shares[_company_name] += _shares_count;
}

void ShareHolder::blockMoney(int _money_of_shares){
    free_money -= _money_of_shares;
    blocked_money += _money_of_shares;
}

void ShareHolder::freeMoney(int _money_of_shares){
    blocked_money -= _money_of_shares;
    free_money += _money_of_shares;
}

void ShareHolder::updatePortfolioAfterBuy(string _company_name, int _money_transfer, int _shares_count){
    blocked_money -= _money_transfer;
    free_shares[_company_name] += _shares_count;
}

void ShareHolder::updatePortfolioAfterSell(string _company_name, int _money_transfer, int _shares_count){
    free_money += _money_transfer;
    blocked_shares[_company_name] -= _shares_count;
}

void ShareHolder::reportPortfolio(StockMarket* market){
    cout << username << " Portfolio" << endl;
    int money_of_free_shares = 0;
    if(!free_shares.empty()){
        for(const auto& pair: free_shares){
            string company_name = pair.first;
            int count = pair.second;
            Company* _target_company = market->getCompany(company_name);
            int share_price  = _target_company->getPrice();
            money_of_free_shares += count * share_price;
        }
    }

    int total_free_assets = free_money + money_of_free_shares;
    cout << "Total free assets: $" << total_free_assets << endl;
    cout << "Free credit: $" << free_money << endl;
    cout << "Locked credit: $" << blocked_money << endl;
    cout << "Free shares:" << endl;
    if(money_of_free_shares == 0){
        cout << "(empty)" << endl;
    }else{
        int i = 1;
        for(const auto& pair: free_shares){
            string company_name = pair.first;
            int count = pair.second;
            cout << i++ << ". " << company_name << ": " << count << endl;
        }
    }
    cout << "Locked shares:" << endl;
    if(blocked_shares.empty()){
        cout << "(empty)" << endl;
    }else{
        int i = 1;
        for(const auto& pair: blocked_shares){
            string company_name = pair.first;
            int count = pair.second;
            cout << i++ << ". " << company_name << ": " << count << endl;
        }
    }
}