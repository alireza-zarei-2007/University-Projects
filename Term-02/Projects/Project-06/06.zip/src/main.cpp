#include <iostream>
#include <vector>
#include <string>
#include "../include/StockMarket.hpp"
#include "../include/CommandHandler.hpp"

using namespace std;

int main(int argc, char* argv[]){
    if(argc != 3){
        cerr << "Exactly two arguments must be entered !" << endl;
        return 1;
    }

    const string COMPANY_DATA_FILE_NAME = argv[1];
    const string SHAREHOLDER_DATA_FILE_NAME = argv[2];

    StockMarket market;
    OrderBook book;
    CommandHandler handler(market, book);

    market.openReadCSVCompany(COMPANY_DATA_FILE_NAME);
    market.openReadCSVshareHolder(SHAREHOLDER_DATA_FILE_NAME);

    handler.run();
    
    return 0;
}