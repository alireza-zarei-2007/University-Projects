#ifndef STOCKMARKET_HPP
#define STOCKMARKET_HPP
#include <vector>
#include <string>
#include "Company.hpp"
#include "ShareHolder.hpp"

using namespace std;

class ShareHolder;
class Company;

class StockMarket {
    public:
    void openReadCSVCompany(string C_file_name);
    void openReadCSVshareHolder(string S_data_file_name);
    void addNewShareHolder(string username, int credit);
    void checkUserExist(string username, int credit);
    bool isUserExist(string username);
    ShareHolder* getShareHolder(string username);
    Company* getCompany(string company_name);

    private:
    vector<Company*> companies;
    vector<ShareHolder*> share_holders;
    string company_data_file_name;
    string shareholder_data_file_name;

    void addFirstCompanies(string company_name, int share_price);
    void addFirstShareholders(string username, int credit, vector<string> name_of_company_shares
                              , vector<int> num_of_shares);
    
};

#endif