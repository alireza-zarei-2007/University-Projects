#ifndef COMPANY_HPP
#define COMPANY_HPP
#include <string>
#include "Order.hpp"
#include "enum.hpp"

using namespace std;
using namespace ordertype;

class Order;

class Company {
    public:
    Company (string n, int price);
    bool isThisMyName(string company_name);
    bool hasBuyOrder(string u_name);
    bool hasSellOrder(string u_name);
    Order* getOrderToMatchFromBuyQueue(int _suggested_price, int _shares_count);
    Order* getOrderToMatchFromSellQueue(int _suggested_price, int _shares_count);
    void addOrderToSellQueue(Order* _order);
    void addOrderToBuyQueue(Order* _order);
    void removeOrdersFromQueues(Order* _buy_order, Order* _sell_order);
    void removeOrderForCanceling(Order* _target_order, type order_type);
    int getPrice();
    void setNewSharePrice(int new_share_price);
    void report();

    private:
    string share_name;
    int share_price;
    vector<Order*> buy_queue;
    vector<Order*> sell_queue;
};

#endif