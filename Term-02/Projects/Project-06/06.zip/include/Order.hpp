#ifndef ORDER_HPP
#define ORDER_HPP
#include <vector>
#include <string>
#include "OrderBook.hpp"
#include "enum.hpp"

using namespace std;
using namespace orderstatus;
using namespace ordertype;

class Order {
    public:
    Order(string _username, int _shares_count, string _company_name, int _suggested_price, type _type, int _order_id);
    void matched();
    void cancelled();
    string getCompanyName();
    int getId();
    type getType();
    string getUsername();
    status getStatus();
    int getSharesCount();
    int getSuggestedPrice();

    private:

    int order_id;
    type my_type;
    status my_status;
    string username;
    int shares_count;
    string company_name;
    int Suggested_price;


};
#endif