#ifndef ENUM_HPP
#define ENUM_HPP

namespace orderstatus {
    enum status {PENDING, MATCHED, CANCELLED};
}
namespace ordertype {
    enum type {BUY, SELL};
}

#endif