#ifndef SHAREHOLDER_HPP
#define SHAREHOLDER_HPP
#include <map>
#include <vector>
#include "Order.hpp"
using namespace std;

class StockMarket;

class ShareHolder {
    public:
    ShareHolder(string u_name, int credit, vector<string> name_of_company_shares
                ,vector<int> num_of_shares);
    ShareHolder(string u_name, int credit);
    bool isThisMyName(string username);
    bool hasEnoughShares(string _company_name, int _shares_count);
    bool hasEnoughMoney(int _money_of_shares);
    void blockShare(string _company_name, int _shares_count);
    void blockMoney(int _money_of_shares);
    void freeShare(string _company_name, int _shares_count);
    void freeMoney(int _money_of_shares);
    void updatePortfolioAfterBuy(string _company_name, int _money_transfer, int _shares_count);
    void updatePortfolioAfterSell(string _company_name, int _money_transfer, int _shares_count);
    void reportPortfolio(StockMarket* market);

    private:

    string username;
    int free_money;
    int blocked_money;
    map<string , int> free_shares;
    map<string, int> blocked_shares;
    int getMySharesCount(string company_name);
};

#endif