#ifndef COMMANDHANDLER_HPP
#define COMMANDHANDLER_HPP
#include <vector>
#include <string>
#include "StockMarket.hpp"
#include "OrderBook.hpp"

using namespace std;

class CommandHandler {
    public:
    CommandHandler(StockMarket& m, OrderBook& o);
    void run();

    private:
    StockMarket& market;
    OrderBook& book;

    void processCommand(string line);
};

#endif