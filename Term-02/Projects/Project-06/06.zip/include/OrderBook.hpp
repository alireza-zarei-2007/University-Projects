#ifndef ORDERBOOK_HPP
#define ORDERBOOK_HPP
#include <vector>
#include <string>
#include "StockMarket.hpp"
#include "Order.hpp"
#include "enum.hpp"


class StockMarket;
class Order;
class Company;
class ShareHolder;

using namespace std;
using namespace ordertype;

class OrderBook {
    public:
    void addNewOrder(string _username, int _shares_count, string _company_name, int _suggested_price, type _type);
    void processOrderMatch(StockMarket* market, string _company_name, int _suggested_price, int _shares_count, Company* _target_company
                            , ShareHolder* _target_holder,  type _my_type);
    
    void findOrderAndCanceling(StockMarket* market, int _target_id);
                            
    private:

    vector<Order*> orders;
    Order* findOrderFromBuyQueue(int _suggested_price, int _shares_count, Company* _target_company);
    Order* findOrderFromSellQueue(int _suggested_price, int _shares_count, Company* _target_company);
    void addToSellQueue(Order* _main_order, Company* _target_company);
    void addToBuyQueue(Order* _main_order, Company* _target_company);
    void match(ShareHolder* _buyer_holder, ShareHolder* _seller_holder, Order* _buy_order, Order* _sell_order, Company* _target_company
                , int _suggested_price, int _shares_count, string _company_name);
    
    void transferMoneyShare(ShareHolder* _buyer_holder, ShareHolder* _seller_holder, int _suggested_price, int _shares_count
                            , string _company_name);

};
#endif