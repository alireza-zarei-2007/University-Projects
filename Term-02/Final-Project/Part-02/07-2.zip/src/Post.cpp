#include "../include/Post.hpp"

const string OK = "OK";
const string EMPTY = "Empty";
const string NOT_FOUND = "Not Found";
const string BAD_REQUEST = "Bad Request";
const string PERMISSION_DENIED = "Permission Denied";
const string USERNAME = "username";
const string LEVEL_MISMATCH = "Level Mismatch";

Post::Post(vector<string> _commnads_noun, string _command_verb): Command(_commnads_noun, _command_verb){}

void Post::printOk() { cout << OK << endl; }

void Post::printEmptyError() { cout << EMPTY << endl; }

void Post::printNotFoundError() { cout << NOT_FOUND << endl; }

void Post::printBadRequestError() { cout << BAD_REQUEST << endl; }

void Post::printPermissionDeniedError() { cout << PERMISSION_DENIED << endl; }

bool Post::generalCheckSyn(string _arguments){
    string word_key;
    string word_value;
    stringstream ss(_arguments);
    while(ss >> word_key){
        if(isCommandSynTrue(word_key)){
            return false;
        }
        if(ss >> word_value){
            if(!isCommandSynTrue(word_value)){
                return false;
            }
        }else{
            return false;
        }
    }
    return true;
}

bool Post::isMyCommandNoun(string cmd_noun){
    bool is_my_command_noun = false;
    for(string noun: commnads_noun){
        if(cmd_noun == noun){
            is_my_command_noun = true;
        }
    }
    return is_my_command_noun;
}

bool Post::isCommandSynTrue(string word){
    if(word.front() == '"' && word.back() == '"' && word.length() >= 2){
        return true;
    }
    return false;
}

bool Post::isUserNameFind(string& username, string word){
    if(word.front() == '"' && word.back() == '"' && word.length() >= 2){
        word = word.substr(1, word.length() - 2);
        username = word;
        return true;
    }
    return false;
}

bool Post::isPassWordFind(string& password, string word){
    if(word.front() == '"' && word.back() == '"' && word.length() >= 2){
        word = word.substr(1, word.length() - 2);
        password = word;
        return true;
    }
    return false;
}

bool Post::hasErrorRegister(Game& game, string _arguments, bool is_username_find, bool is_password_find, string username){
    if(!generalCheckSyn(_arguments)){
        printBadRequestError();
        return true;
    }
    
    if(!is_username_find || !is_password_find){
        printBadRequestError();
        return true;
    }
    if(game.admin_logged_in != nullptr || game.player_logged_in != nullptr){
        printPermissionDeniedError();
        return true;
    }
    if(game.isUserNameExist(username)){
        printBadRequestError();
        return true;
    }

    return false;
}

void Post::checkArgumentsRegisterAndProcess(Game& game, string _arguments){
    string username;
    string password;
    bool is_username_find = false;
    bool is_password_find = false;
    string word_key;
    string word_value;

    stringstream ss(_arguments);
    while(ss >> word_key){
        if(word_key == USERNAME){
            if(ss >> word_value){
                is_username_find = isUserNameFind(username, word_value);
            }
        }else if(word_key == "password"){
            if(ss >> word_value){
                is_password_find = isPassWordFind(password, word_value);
            }
        }
        if(is_username_find && is_password_find) break;
    }

    if(hasErrorRegister(game, _arguments, is_username_find, is_password_find, username)) return;

    game.addPlayer(username, password, 0, 0, false);
    printOk();
}

bool Post::hasErrorLogin(Game& game, string _arguments, bool is_username_find, bool is_password_find, string username, string password){
    if(!generalCheckSyn(_arguments)){
        printBadRequestError();
        return true;
    }

    if(!is_username_find || !is_password_find){
        printBadRequestError();
        return true;
    }

    if(game.admin_logged_in != nullptr || game.player_logged_in != nullptr){
        printPermissionDeniedError();
        return true;
    }

    if(!game.isUserNameExist(username)){
        printNotFoundError();
        return true;
    }

    if(!game.isPassWordCorrect(username, password)){
        printPermissionDeniedError();
        return true;
    }

    return false;
}

void Post::checkArgumentsLoginAndProcess(Game& game, string _arguments){
    string username;
    string password;
    bool is_username_find = false;
    bool is_password_find = false;
    string word_key;
    string word_value;

    stringstream ss(_arguments);
    while(ss >> word_key){
        if(word_key == USERNAME){
            if(ss >> word_value){
                is_username_find = isUserNameFind(username, word_value);
            }
        }else if(word_key == "password"){
            if(ss >> word_value){
                is_password_find = isPassWordFind(password, word_value);
            }
        }
        if(is_username_find && is_password_find) break;
    }

    if(hasErrorLogin(game, _arguments, is_username_find, is_password_find, username, password)) return;

    game.login(username);
    printOk();
}

void Post::checkArgumentsLogOutAndProcess(Game& game, string _arguments){
    if(!generalCheckSyn(_arguments)){
        printBadRequestError();
        return;
    }

    if(game.admin_logged_in == nullptr && game.player_logged_in == nullptr){
        printPermissionDeniedError();
        return;
    }

    game.logout();
    printOk();
}

bool Post::isStatusSynTrue(bool& status, string word){
    word = word.substr(1, word.length() - 2);
    if(word == "true"){
        status = true;
        return true;
    }else if(word == "false"){
        status = false;
        return true;
    }else{
        return false;
    }
}

bool Post::hasErrorCMReady(Game& game, string _arguments, bool is_command_syn_true, bool is_status_syn_true){
    if(!generalCheckSyn(_arguments)){
        printBadRequestError();
        return true;
    }

    if(!is_command_syn_true){
        printBadRequestError();
        return true;
    }

    if((game.admin_logged_in != nullptr) || (game.admin_logged_in == nullptr && game.player_logged_in == nullptr)){
        printPermissionDeniedError();
        return true;
    }

    if(!is_status_syn_true){
        printBadRequestError();
        return true;
    }

    return false;
}

void Post::checkArgumentsCMReadyAndProcess(Game& game, string _arguments){
    bool status;
    string word_key;
    string word_value;
    bool is_status_syn_true = false;
    bool is_command_syn_true = false;

    stringstream ss(_arguments);
    while(ss >> word_key){
        if(word_key == "status"){
            if(ss >> word_value){
                is_command_syn_true = isCommandSynTrue(word_value);
                if(is_command_syn_true){
                    is_status_syn_true = isStatusSynTrue(status, word_value);
                }
            }
        }
        if(is_status_syn_true) break;
    }

    if(hasErrorCMReady(game, _arguments, is_command_syn_true, is_status_syn_true)) return;

    game.setStatusReady(status);
    printOk();

}

void Post::setValueOnObject(string& object, string word){
    word = word.substr(1, word.length() - 2);
    object = word;
}

bool Post::hasErrorInvite(Game& game, string _arguments, bool is_command_syn_true1, bool is_command_syn_true2
                            , string username, string match_type){
    
    if(!generalCheckSyn(_arguments)){
        printBadRequestError();
        return true;
    }

    if(!is_command_syn_true1 || !is_command_syn_true2){
        printBadRequestError();
        return true;
    }

    if((game.admin_logged_in != nullptr) || (game.admin_logged_in == nullptr && game.player_logged_in == nullptr)){
        printPermissionDeniedError();
        return true;
    }

    if(username == game.player_logged_in->getUserName()){
        printNotFoundError();
        return true;
    }

    if(game.isUserNameForAdmin(username)){
        printPermissionDeniedError();
        return true;
    }

    if(!game.isUserNameForPlayer(username)){
        printNotFoundError();
        return true;
    }

    if(match_type != "casual" && match_type != "ranked"){
        printBadRequestError();
        return true;
    }

    return false;
}

void Post::checkArgumentsInviteAndProcess(Game& game, string _arguments){
    string username;
    string match_type;
    bool is_username_find = false;
    bool is_matchtype_find = false;
    bool is_command_syn_true1 = false;
    bool is_command_syn_true2 = false;
    string word_key;
    string word_value;

    stringstream ss1(_arguments);
    stringstream ss2(_arguments);
    while(ss1 >> word_key){
        if(word_key == USERNAME){
            if(ss1 >> word_value){
                is_command_syn_true1 = isCommandSynTrue(word_value);
                if(is_command_syn_true1){
                    setValueOnObject(username, word_value);
                }
            }
        }
    }
    while(ss2 >> word_key){
        if(word_key == "match_type"){
            if(ss2 >> word_value){
                is_command_syn_true2 = isCommandSynTrue(word_value);
                if(is_command_syn_true2){
                    setValueOnObject(match_type, word_value);
                }
            }
        }
    }

    if(hasErrorInvite(game, _arguments, is_command_syn_true1, is_command_syn_true2, username, match_type)) return;

    Player* target_player = game.getPlayerByUserName(username);
    if(game.player_logged_in->isThisPlayerBlockedMe(target_player)){
        printNotFoundError();
        return;
    }

    game.setInvitation(username, match_type);
    printOk();
}

void Post::checkArgumentsRejInviteAndProcess(Game& game, string _arguments){
    int invite_id;
    string invite_id_str;
    string word_key;
    string word_value;
    bool is_command_syn_true = false;

    stringstream ss(_arguments);
    while(ss >> word_key){
        if(word_key == "invitation_id"){
            if(ss >> word_value){
                is_command_syn_true = isCommandSynTrue(word_value);
                if(is_command_syn_true) setValueOnObject(invite_id_str, word_value);
            }
        }
    }

    if(!generalCheckSyn(_arguments)){
        printBadRequestError();
        return;
    }

    if(!is_command_syn_true){
        printBadRequestError();
        return;
    }

    if((game.admin_logged_in != nullptr) || (game.admin_logged_in == nullptr && game.player_logged_in == nullptr)){
        printPermissionDeniedError();
        return;
    }

    invite_id = stoi(invite_id_str);
    if(!game.player_logged_in->isReceivedInvitationExistAndPending(invite_id)){
        printNotFoundError();
        return;
    }

    game.setInvitationRejected(invite_id);
    printOk();

}

void Post::checkArgumentsStartMatchAndProcess(Game& game, string _arguments){
    int invite_id;
    string invite_id_str;
    string word_key;
    string word_value;
    bool is_command_syn_true = false;

    stringstream ss(_arguments);
    while(ss >> word_key){
        if(word_key == "invitation_id"){
            if(ss >> word_value){
                is_command_syn_true = isCommandSynTrue(word_value);
                if(is_command_syn_true) setValueOnObject(invite_id_str, word_value);
            }
        }
    }

    if(!generalCheckSyn(_arguments)){
        printBadRequestError();
        return;
    }

    if(!is_command_syn_true){
        printBadRequestError();
        return;
    }

    if((game.admin_logged_in != nullptr) || (game.admin_logged_in == nullptr && game.player_logged_in == nullptr)){
        printPermissionDeniedError();
        return;
    }

    invite_id = stoi(invite_id_str);
    if(!game.player_logged_in->isReceivedInvitationExistAndPending(invite_id)){
        printNotFoundError();
        return;
    }

    
    string sender_name = game.getInvitationById(invite_id)->get_sender_name();
    Player* sender = game.getPlayerByUserName(sender_name);
    if(game.player_logged_in->is_playing || sender->is_playing){
        printPermissionDeniedError();
        return;
    }

    gamet game_type = game.getInvitationById(invite_id)->get_game_type();
    if(game_type == RANKED){
        if(game.player_logged_in->rank_level != sender->rank_level){
            cout << LEVEL_MISMATCH << endl;
            game.getInvitationById(invite_id)->my_status = REJECTED;
            return;
        }
    }

    game.setInvitationAccepted(invite_id);
    game.createNewGameAndAddPlayers(game.player_logged_in, sender, game_type);
    printOk(); 
}

bool Post::isActionSynTrue(string word){
    return word == SHOOT || word == DEFEND || word == RELOAD;
}

void Post::checkArgumentsActionAndProcess(Game& game, string _arguments){
    string action;
    string word_key;
    string word_value;
    bool is_action_syn_true = false;
    bool is_command_syn_true = false;

    stringstream ss(_arguments);
    while(ss >> word_key){
        if(word_key == "action"){
            if(ss >> word_value){
                is_command_syn_true = isCommandSynTrue(word_value);
                if(is_command_syn_true){
                    setValueOnObject(action, word_value);
                    if(isActionSynTrue(action)) is_action_syn_true = true;
                }
            }
        }
    }

    if(!generalCheckSyn(_arguments)){
        printBadRequestError();
        return;
    }

    if(!is_command_syn_true){
        printBadRequestError();
        return;
    }

    if((game.admin_logged_in != nullptr) || (game.admin_logged_in == nullptr && game.player_logged_in == nullptr)){
        printPermissionDeniedError();
        return;
    }

    if(!is_action_syn_true){
        printBadRequestError();
        return;
    }

    if(!game.player_logged_in->is_playing){
        printNotFoundError();
        return;
    }
    
    if(game.player_logged_in->get_current_game_casual() != nullptr){
        Casual* current_game = game.player_logged_in->get_current_game_casual();
        if(current_game->canPlayerMove(game.player_logged_in)){
            if(action == SHOOT && !current_game->hasEnoughBullets(game.player_logged_in)){
                printBadRequestError();
                return;
            }else{
                current_game->processAction(game.player_logged_in, action);
                printOk();
                return;
            }
        }else{
            printPermissionDeniedError();
            return;
        }
    }

    if(game.player_logged_in->get_current_game_ranked() != nullptr){
        Ranked* current_game = game.player_logged_in->get_current_game_ranked();
        if(current_game->canPlayerMove(game.player_logged_in)){
            if(action == SHOOT && !current_game->hasEnoughBullets(game.player_logged_in)){
                printBadRequestError();
                return;
            }else{
                current_game->processAction(game.player_logged_in, action);
                printOk();
                return;
            }
        }else{
            printPermissionDeniedError();
            return;
        }
    }
}

void Post::checkArgumentsReportAndProcess(Game& game, string _arguments){
    string username_value;
    string reason_value;
    bool is_user_key_exist = false;
    bool is_reaon_key_exist = false;
    string word_key;
    string word_value;
    string none;
    string main_argument = _arguments;

    stringstream ss1(_arguments);
    while (ss1 >> word_key){
        if(word_key == "reason") is_reaon_key_exist = true;
        if(word_key == USERNAME) is_user_key_exist = true;
    }
    
    if(!is_reaon_key_exist || !is_user_key_exist){
        printBadRequestError();
        return;
    }

    size_t reason_pos = _arguments.find("reason");

    size_t reason_value_start = _arguments.find('"', reason_pos);
    if(reason_value_start == string::npos){
        printBadRequestError();
        return;
    }
    size_t reason_value_end = _arguments.find('"', reason_value_start + 1);
    if(reason_value_end == string::npos){
        printBadRequestError();
        return;
    }

    string reason_key_and_value = _arguments.substr(reason_pos, reason_value_end - reason_pos + 1);
    _arguments.erase(reason_pos, reason_value_end - reason_pos + 1);

    if(!generalCheckSyn(_arguments)){
        printBadRequestError();
        return;
    }

    stringstream ss2(reason_key_and_value);
    ss2 >> none;
    if(ss2 >> none){
        if(none[0] != '"'){
            printBadRequestError();
            return;
        }
    }

    reason_value = main_argument.substr(reason_value_start+1, reason_value_end - reason_value_start - 1);

    stringstream ss3(main_argument);
    while(ss3 >> word_key){
        if(word_key == USERNAME){
            if(ss3 >> word_value){
                setValueOnObject(username_value, word_value);
            }
        }
    }

    if((game.admin_logged_in != nullptr) || (game.admin_logged_in == nullptr && game.player_logged_in == nullptr)){
        printPermissionDeniedError();
        return;
    }

    if(username_value == game.player_logged_in->getUserName()){
        printNotFoundError();
        return;
    }

    if(!game.isUserNameForPlayer(username_value)){
        printNotFoundError();
        return;
    }

    if(game.isUserNameForAdmin(username_value)){
        printPermissionDeniedError();
        return;
    }

    if(isBlank(reason_value)){
        printBadRequestError();
        return;
    }

    game.setReport(username_value, reason_value);
    printOk();
    return;
}

bool Post::isBlank(string line){
    for(char c : line){
        if(!isspace(c)) return false;
    }
    return true;
}

void Post::checkArgumentsBlockAndProcess(Game& game, string _arguments){
    string word_key;
    string value_key;
    string username;
    string status_block;
    bool is_username_find = false;
    bool is_status_find = false;

    if(!generalCheckSyn(_arguments)){
        printBadRequestError();
        return;
    }

    stringstream ss(_arguments);
    while(ss >> word_key){
        ss >> value_key;
        if(word_key == "username"){
            is_username_find = true;
            setValueOnObject(username, value_key);
        }
        if(word_key == "status"){
            is_status_find = true;
            setValueOnObject(status_block, value_key);
        }
        if(is_username_find && is_status_find) break;
    }

    if(!is_username_find || !is_status_find){
        printBadRequestError();
        return;
    }

    if((game.admin_logged_in != nullptr) || (game.admin_logged_in == nullptr && game.player_logged_in == nullptr)){
        printPermissionDeniedError();
        return;
    }

    if(status_block != "blocked" && status_block != "unblocked"){
        printBadRequestError();
        return;
    }

    if(!game.isUserNameExist(username)){
        printNotFoundError();
        return;
    }

    if(game.isUserNameForAdmin(username)){
        printBadRequestError();
        return;
    }

    game.processBlockPlayer(username, status_block);
    printOk();
    return;
}

bool Post::isAllArgumentsPenaltyFound(bool report, bool types, bool amount, bool matches){
    return report && types && amount && matches;
}

bool Post::isNumber(string line){
    char ch;
    for(int i=0; i<line.length(); i++){
        ch = line[i];
        if(!(47 < ch && ch < 58)) return false;
    }
    return true;
}

void Post::checkArgumentsPenaltyAndProcess(Game& game, string _arguments){
    string word_key;
    string word_value;
    string str_report_id;
    int report_id;
    string types;
    string str_amount;
    int amount;
    string  str_num_of_matches;
    int num_of_matches;

    bool is_report_id_found = false;
    bool is_type_found = false;
    bool is_amount_found = false;
    bool is_num_of_matches_found = false;

    if(!generalCheckSyn(_arguments)){
        printBadRequestError();
        return;
    }

    stringstream ss(_arguments);
    while(ss >> word_key){
        if(ss >> word_value){
            if(word_key == "report_id"){
                is_report_id_found = true;
                setValueOnObject(str_report_id, word_value);
                report_id = stoi(str_report_id);
            }
            if(word_key == "type"){
                is_type_found = true;
                setValueOnObject(types, word_value);
            }
            if(word_key == "amount"){
                is_amount_found = true;
                setValueOnObject(str_amount, word_value);
            }
            if(word_key == "number_of_matches"){
                is_num_of_matches_found = true;
                setValueOnObject(str_num_of_matches, word_value);
            }
        }
        if(isAllArgumentsPenaltyFound(is_report_id_found, is_type_found, is_amount_found, is_num_of_matches_found)) break;
    }

    if(!isAllArgumentsPenaltyFound(is_report_id_found, is_type_found, is_amount_found, is_num_of_matches_found)){
        printBadRequestError();
        return;
    }

    if((game.player_logged_in != nullptr) || (game.admin_logged_in == nullptr && game.player_logged_in == nullptr)){
        printPermissionDeniedError();
        return;
    }

    if(!game.isReportOpen(report_id)){
        printNotFoundError();
        return;
    }

    if(types != "health_penalty" && types != "bullet_penalty"){
        printBadRequestError();
        return;
    }

    if(types == "health_penalty"){
        if(isNumber(str_amount)){
            amount = stoi(str_amount);
            if(!(amount >= 1 && amount <= 2)){
                printBadRequestError();
                return;
            }
        }
    }
    
    if(types == "bullet_penalty"){
        if(isNumber(str_amount)){
            amount = stoi(str_amount);
            if(!(amount >= 1 && amount <= 3)){
                printBadRequestError();
                return;
            }
        }
    }

    if(isNumber(str_num_of_matches)){
        num_of_matches = stoi(str_num_of_matches);
        if(num_of_matches < 1){
            printBadRequestError();
            return;
        }
    }
    
    game.setPenalty(report_id, types, amount, num_of_matches);
    printOk();
    return;
}

void Post::checkArgumentsDismissReportAndProcess(Game& game, string _arguments){
    string word_key;
    string word_value;
    string str_report_id;
    int report_id;

    bool is_report_id_found = false;

    if(!generalCheckSyn(_arguments)){
        printBadRequestError();
        return;
    }

    stringstream ss(_arguments);
    while(ss >> word_key){
        if(ss >> word_value){
            if(word_key == "report_id"){
                is_report_id_found = true;
                setValueOnObject(str_report_id, word_value);
                report_id = stoi(str_report_id);
            }
        }
        if(is_report_id_found) break;
    }

    if(!is_report_id_found){
        printBadRequestError();
        return;
    }

    if((game.player_logged_in != nullptr) || (game.admin_logged_in == nullptr && game.player_logged_in == nullptr)){
        printPermissionDeniedError();
        return;
    }

    if(!game.isReportOpen(report_id)){
        printNotFoundError();
        return;
    }

    game.reportClosed(report_id);
    printOk();
    return;
}