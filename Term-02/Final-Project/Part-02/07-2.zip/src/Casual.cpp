#include "../include/Casual.hpp"

const string ISPLAYED = "played";

Casual::Casual(Player* _player1, Player* _player2): player1(_player1), player2(_player2)
            , in_progress(true), pending_turn(1), remaining_bullets_player1(1), remaining_bullets_player2(1){}

bool Casual::canPlayerMove(Player* player){
    if(isPlayerOne(player)){
        return player1_moves.size() <= player2_moves.size();
    }else{
        return player2_moves.size() <= player1_moves.size();
    }
}

bool Casual::hasEnoughBullets(Player* player){
    if(isPlayerOne(player)){
        return remaining_bullets_player1 > 0;
    }else{
        return remaining_bullets_player2 > 0;
    }
}

bool Casual::isPlayerOne(Player* player){
    return player == player1;
}

void Casual::doAction(){
    string current_action_player1 = player1_moves[pending_turn - 1];
    string current_action_player2 = player2_moves[pending_turn - 1];
    if((current_action_player1 == SHOOT || current_action_player1 == DEFEND) && (current_action_player2 == SHOOT || current_action_player2 == DEFEND)){
        return;
    }
    if((current_action_player1 == RELOAD || current_action_player1 == DEFEND) && (current_action_player2 == RELOAD || current_action_player2 == DEFEND)){
        return;
    }
    if(current_action_player1 == SHOOT && current_action_player2 == RELOAD){
        float delta_xp = 50 - (0.1 * (player1->getXp() - player2->getXp()));
        delta_xp = delta_xp >= 5 ? delta_xp : 5;
        player1->is_playing = false;
        player2->is_playing = false;
        player1->total_win += 1;
        player2->total_lose += 1;
        player1->changeXpAfterGame(delta_xp);
        player2->changeXpAfterGame(0 - delta_xp);
        player1->casualGameEnded();
        player2->casualGameEnded();
        in_progress = false;
        return;
    }
    if(current_action_player2 == SHOOT && current_action_player1 == RELOAD){
        float delta_xp = 50 - (0.1 * (player2->getXp() - player1->getXp()));
        delta_xp = delta_xp >= 5 ? delta_xp : 5;
        player1->is_playing = false;
        player2->is_playing = false;
        player2->total_win += 1;
        player1->total_lose += 1;
        player2->changeXpAfterGame(delta_xp);
        player1->changeXpAfterGame(0 - delta_xp);
        player1->casualGameEnded();
        player2->casualGameEnded();
        in_progress = false;
        return;
    }
}

void Casual::processAction(Player* player, string action){
    if(isPlayerOne(player)){
        player1_moves.push_back(action);
        if(action == SHOOT){
            remaining_bullets_player1 -= 1;
            if(player1_moves.size() == player2_moves.size()){
                doAction();
                pending_turn += 1;
                return;
            }else{
                return;
            }
        }
        if(action == DEFEND){
            if(player1_moves.size() == player2_moves.size()){
                doAction();
                pending_turn += 1;
                return;
            }else{
                return;
            }
        }
        if(action == RELOAD){
            remaining_bullets_player1 += 1;
            if(player1_moves.size() == player2_moves.size()){
                doAction();
                pending_turn += 1;
                return;
            }else{
                return;
            }
        }
    }else{
        player2_moves.push_back(action);
        if(action == SHOOT){
            remaining_bullets_player2 -= 1;
            if(player2_moves.size() == player1_moves.size()){
                doAction();
                pending_turn += 1;
                return;
            }else{
                return;
            }
        }
        if(action == DEFEND){
            if(player2_moves.size() == player1_moves.size()){
                doAction();
                pending_turn += 1;
                return;
            }else{
                return;
            }
        }
        if(action == RELOAD){
            remaining_bullets_player2 += 1;
            if(player2_moves.size() == player1_moves.size()){
                doAction();
                pending_turn += 1;
                return;
            }else{
                return;
            }
        }
    }
}

string Casual::makeLineForPrintHistory(string your_moves, string o_moves){
    string line = o_moves;
    while(line.length() != 20){
        line += " ";
    }
    line += your_moves;
    return line;
}

void Casual::printMatchStatus(Player* player){
    string you;
    string your_o;
    string your_moves;
    string o_moves;
    if(isPlayerOne(player)){
        cout << "Turn " << pending_turn << endl; 
        if(player1_moves.size() == pending_turn){
            you = player1_moves[pending_turn - 1];
        }else{
            you = ISPENDING;
        }

        if(player2_moves.size() == pending_turn){
            your_o = ISPLAYED;
        }else{
            your_o = ISPENDING;
        }

        cout << "You: " << you << endl;
        cout << "Your opponent: " << your_o << endl;
        cout << "History:" << endl;
        cout << "Opponent's moves:   Your moves:" << endl;
        if(pending_turn != 1){
            for(int i=0; i< pending_turn - 1; i++){
                o_moves = player2_moves[i];
                your_moves = player1_moves[i];
                cout << makeLineForPrintHistory(your_moves, o_moves) << endl;
            }
        }
        cout << "Your remaining bullets: " << ((you == ISPENDING || you == DEFEND) ? remaining_bullets_player1 : (you == SHOOT ? remaining_bullets_player1 + 1 : remaining_bullets_player1 - 1)) << endl;
    }else{
        cout << "Turn " << pending_turn << endl; 
        if(player2_moves.size() == pending_turn){
            you = player2_moves[pending_turn - 1];
        }else{
            you = ISPENDING;
        }

        if(player1_moves.size() == pending_turn){
            your_o = ISPLAYED;
        }else{
            your_o = ISPENDING;
        }

        cout << "You: " << you << endl;
        cout << "Your opponent: " << your_o << endl;
        cout << "History:" << endl;
        cout << "Opponent's moves:   Your moves:" << endl;
        if(pending_turn != 1){
            for(int i=0; i< pending_turn - 1; i++){
                o_moves = player1_moves[i];
                your_moves = player2_moves[i];
                cout << makeLineForPrintHistory(your_moves, o_moves) << endl;
            }
        }
        cout << "Your remaining bullets: " << ((you == ISPENDING || you == DEFEND) ? remaining_bullets_player2  : (you == SHOOT ? remaining_bullets_player2 + 1 : remaining_bullets_player2 - 1)) << endl;
    }
}