#include "../include/Penalty.hpp"

Penalty::Penalty(int amount, int num_of_match, pent penalty_type){
    if(penalty_type == HEALTH){
        am_health_pen = amount;
        num_of_match_health = num_of_match;
        am_bullet_pen = 0;
        num_of_match_bullet = 0;
    }
    if(penalty_type == BULLET){
        am_bullet_pen = amount;
        num_of_match_bullet = num_of_match;
        am_health_pen = 0;
        num_of_match_health = 0;
    }
}

void Penalty::changeInformationPen(int amount, int num_of_match, pent penalty_type){
    if(penalty_type == HEALTH){
        am_health_pen = amount;
        num_of_match_health = num_of_match;
    }
    if(penalty_type == BULLET){
        am_bullet_pen = amount;
        num_of_match_bullet = num_of_match;
    }
}