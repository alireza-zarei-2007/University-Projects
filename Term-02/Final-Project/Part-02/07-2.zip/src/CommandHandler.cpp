#include <iostream>
#include <sstream>
#include "../include/CommandHandler.hpp"

const string OK = "OK";
const string EMPTY = "Empty";
const string NOT_FOUND = "Not Found";
const string BAD_REQUEST = "Bad Request";
const string PERMISSION_DENIED = "Permission Denied";

const string REGISTER = "register";
const string LOGIN = "login";
const string LOGOUT = "logout";
const string CASUAL_MATCH_READY = "casual_match_ready";
const string INVITATION = "invitation";
const string REJECT_INVITATION = "reject_invitation";
const string START_MATCH = "start_match";
const string ACTION = "action";
const string REPORT = "report";
const string CASUAL_MATCH_OPPONENTS = "casual_match_opponents";
const string MATCH_STATUS = "match_status";
const string PROFILE = "profile";
const string RECEIVED_INVITATIONS = "received_invitations";
const string REPORTS = "reports";
const string RANKED_MATCH_OPPONENTS = "ranked_match_opponents";
const string BLOCK = "block";
const string PENALTY = "penalty";
const string DISMISS_REPORT = "dismiss_report";

CommandHandler::CommandHandler(Game& game): game(game) {}

void CommandHandler::processCommandNoun(Get get, Post post, string cmd, string cmd_noun, string arguments){
    if(cmd == "POST"){
        if(cmd_noun == REGISTER){
            post.checkArgumentsRegisterAndProcess(game, arguments);
        }
        if(cmd_noun == LOGIN){
            post.checkArgumentsLoginAndProcess(game, arguments);
        }
        if(cmd_noun == LOGOUT){
            post.checkArgumentsLogOutAndProcess(game, arguments);
        }
        if(cmd_noun == CASUAL_MATCH_READY){
            post.checkArgumentsCMReadyAndProcess(game, arguments);
        }
        if(cmd_noun == INVITATION){
            post.checkArgumentsInviteAndProcess(game, arguments);
        }
        if(cmd_noun == REJECT_INVITATION){
            post.checkArgumentsRejInviteAndProcess(game, arguments);
        }
        if(cmd_noun == START_MATCH){
            post.checkArgumentsStartMatchAndProcess(game, arguments);
        }
        if(cmd_noun == ACTION){
            post.checkArgumentsActionAndProcess(game, arguments);
        }
        if(cmd_noun == REPORT){
            post.checkArgumentsReportAndProcess(game, arguments);
        }
        if(cmd_noun == BLOCK){
            post.checkArgumentsBlockAndProcess(game ,arguments);
        }
        if(cmd_noun == PENALTY){
            post.checkArgumentsPenaltyAndProcess(game, arguments);
        }
        if(cmd_noun == DISMISS_REPORT){
            post.checkArgumentsDismissReportAndProcess(game, arguments);
        }
    }
    
    if(cmd == "GET"){
        if(cmd_noun == CASUAL_MATCH_OPPONENTS){
            get.checkArgumentsCMOpponentsAndProcess(game, arguments);
        }
        if(cmd_noun == MATCH_STATUS){
            get.checkArgumentsMatchStatusAndProcess(game, arguments);
        }
        if(cmd_noun == PROFILE){
            get.checkArgumentsProfileAndProcess(game, arguments);
        }
        if(cmd_noun == RECEIVED_INVITATIONS){
            get.checkArgumentsPrintInvitationsAndProcess(game, arguments);
        }
        if(cmd_noun == REPORTS){
            get.checkArgumentsPrintReportsAndProcess(game, arguments);
        }
        if(cmd_noun == RANKED_MATCH_OPPONENTS){
            get.checkArgumentsRMOpponentsAndProcess(game, arguments);
        }
    }
}

void CommandHandler::processCommand(string line){

    vector<string> post_commands_noun = {REGISTER, LOGIN, LOGOUT, CASUAL_MATCH_READY, INVITATION, START_MATCH
                                        , REJECT_INVITATION, ACTION, REPORT, BLOCK, PENALTY, DISMISS_REPORT};
    vector<string> get_commands_noun = {CASUAL_MATCH_OPPONENTS, MATCH_STATUS, PROFILE, RECEIVED_INVITATIONS, REPORTS, RANKED_MATCH_OPPONENTS};
    vector<string> put_commands_noun;
    vector<string> delete_commands_noun;

    Post post(post_commands_noun, "POST");
    Get get(get_commands_noun, "GET");
 
    stringstream ss(line);
    string cmd;
    string cmd_noun;
    string question_mark;
    string arguments;
    ss >> cmd >> cmd_noun >> question_mark;
    getline(ss, arguments);

    if(cmd != "POST" && cmd != "GET" && cmd != "PUT" && cmd != "DELETE"){
        cout << BAD_REQUEST << endl;
        return;
    }

    if(cmd == "POST"){
        if(!post.isMyCommandNoun(cmd_noun)){
            cout << NOT_FOUND << endl;
            return;
        }else if(question_mark != "?"){
            cout << BAD_REQUEST << endl;
            return;
        }

        processCommandNoun(get, post, cmd, cmd_noun, arguments);
    }

    if(cmd == "GET"){
        if(!get.isMyCommandNoun(cmd_noun)){
            cout << NOT_FOUND << endl;
            return;
        }else if(question_mark != "?"){
            cout << BAD_REQUEST << endl;
            return;
        }

        processCommandNoun(get, post, cmd, cmd_noun, arguments);
    }

}

void CommandHandler::run(string player_file, string admin_file){
    string line;

    game.openReadCSVPlayers(player_file);
    game.openReadCSVAdmins(admin_file);

    while(getline(cin, line)){
        processCommand(line);
    }
}