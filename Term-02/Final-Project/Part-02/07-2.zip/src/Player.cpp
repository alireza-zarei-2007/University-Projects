#include "../include/Player.hpp"

Player::Player(string _username, string _password): Member(_username, _password), xp(500.0), rp(1200.0)
                                                , total_win(0), total_lose(0),  ready_to_play(false)
                                                , is_playing(false), rank_level(BRONZE), current_game_casual(nullptr)
                                                , current_game_ranked(nullptr){}

Player::Player(string _username, string _password, float _xp, float _rp): Member(_username, _password), xp(_xp), rp(_rp)
                                                        , total_win(0), total_lose(0), ready_to_play(false)
                                                        , is_playing(false), current_game_casual(nullptr), current_game_ranked(nullptr)
{
    updateRank();
}

void Player::updateRank(){
    if(rp < 1400){
        rank_level = BRONZE;
    }
    if(rp >= 1400 && rp < 1750){
        rank_level = SILVER;
    }
    if(rp >= 1750 && rp < 2250){
        rank_level = GOLD;
    }
    if(rp >= 2250){
        rank_level = PLATINUM;
    }
}

float Player::getXp(){ return xp; }

float Player::getRp(){ return rp; }

int Player::getNewInvitationId(){ return sent_invitations.size() + 1; }

void Player::addReceivedInvitation(Invitation* new_invitation){
    received_invitations.push_back(new_invitation);
}

void Player::addSentInvitation(Invitation* new_invitation){
    sent_invitations.push_back(new_invitation);
}

bool Player::isReceivedInvitationExistAndPending(int invite_id){
    for(Invitation* invitation: received_invitations){
        if(invitation->app_level_id == invite_id && invitation->my_status == PENDING){
            return true;
        }
    }
    return false;
}

void Player::joinGame(Casual* game_casual, Ranked* game_ranked){
    if(game_casual != nullptr){
        current_game_casual = game_casual;
        is_playing = true;
    }
    if(game_ranked != nullptr){
        current_game_ranked = game_ranked;
        is_playing = true;
    }
}

Casual* Player::get_current_game_casual(){ return current_game_casual; }

Ranked* Player::get_current_game_ranked(){ return current_game_ranked; }

void Player::changeXpAfterGame(float delta_xp){
    xp += delta_xp;
}

void Player::changeRpAfterGame(float delta_rp){
    rp += delta_rp;
    updateRank();
}

void Player::casualGameEnded(){
    current_game_casual = nullptr;
}

void Player::rankedGameEnded(){
    current_game_ranked = nullptr;
}

int Player::getNewReportId(){ return sent_reports.size() + 1; }

void Player::addSentReport(Report* new_report){
    sent_reports.push_back(new_report);
}

bool Player::isReceivedInvitationsEmpty(){
    for(Invitation* invitation: received_invitations){
        if(invitation->my_status == PENDING){
            return false;
        }
    }
    return true;
}

void Player::printReceivedInvitations(){
    for(Invitation* invitation : received_invitations){
        if(invitation->my_status == PENDING){
            cout << invitation->app_level_id << ": Invitation from " << '"' 
            << invitation->get_sender_name() << '"' << " for a " << "\"casual\"" << " match" << endl;
        }
    }
}

void Player::addPlayerBlockMe(Player* player_blocked_me){
    auto it = find(players_blocked_me.begin(), players_blocked_me.end(), player_blocked_me);
    if(it == players_blocked_me.end()){
        players_blocked_me.push_back(player_blocked_me);
    }
}

void Player::removePlayerBlockMe(Player* player_blocked_me){
    auto it = find(players_blocked_me.begin(), players_blocked_me.end(), player_blocked_me);
    if(it != players_blocked_me.end()){
        players_blocked_me.erase(it);
    }
}

bool Player::isThisPlayerBlockedMe(Player* target_player){
    auto it = find(players_blocked_me.begin(), players_blocked_me.end(), target_player);
    return it != players_blocked_me.end();
}