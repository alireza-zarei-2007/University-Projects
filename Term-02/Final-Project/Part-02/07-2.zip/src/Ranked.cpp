#include "../include/Ranked.hpp"

const string ISPLAYED = "played";

Ranked::Ranked(Player* _player1, Player* _player2): player1(_player1), player2(_player2)
            , in_progress(true), pending_turn(1), remaining_bullets_player1(3), remaining_bullets_player2(3)
            , player1_lives(3), player2_lives(3){}

bool Ranked::canPlayerMove(Player* player){
    if(isPlayerOne(player)){
        return player1_moves.size() <= player2_moves.size();
    }else{
        return player2_moves.size() <= player1_moves.size();
    }
}

bool Ranked::hasEnoughBullets(Player* player){
    if(isPlayerOne(player)){
        return remaining_bullets_player1 > 0;
    }else{
        return remaining_bullets_player2 > 0;
    }
}

bool Ranked::isPlayerOne(Player* player){
    return player == player1;
}

void Ranked::doAction(){
    string current_action_player1 = player1_moves[pending_turn - 1];
    string current_action_player2 = player2_moves[pending_turn - 1];
    if((current_action_player1 == SHOOT || current_action_player1 == DEFEND) && (current_action_player2 == SHOOT || current_action_player2 == DEFEND)){
        return;
    }
    if((current_action_player1 == RELOAD || current_action_player1 == DEFEND) && (current_action_player2 == RELOAD || current_action_player2 == DEFEND)){
        return;
    }
    if(current_action_player1 == SHOOT && current_action_player2 == RELOAD){
        player2_lives -= 1;
        if(player2_lives == 0){
            rlevel rank = player1->rank_level;
            float delta_rp = ((rank == PLATINUM || rank == GOLD) ? (rank == PLATINUM ? 150.0 : 125.0) : (rank == SILVER ? 100.0 : 75.0));
            float health_bonus = player1_lives * 25.0;
            player1->is_playing = false;
            player2->is_playing = false;
            player1->total_win += 1;
            player2->total_lose += 1;
            player1->changeRpAfterGame(delta_rp + health_bonus);
            player2->changeRpAfterGame(0 - delta_rp);
            player1->rankedGameEnded();
            player2->rankedGameEnded();
            in_progress = false;
            return;
        }
        return;
    }
    if(current_action_player2 == SHOOT && current_action_player1 == RELOAD){
        player1_lives -= 1;
        if(player1_lives == 0){
            rlevel rank = player1->rank_level;
            float delta_rp = ((rank == PLATINUM || rank == GOLD) ? (rank == PLATINUM ? 150.0 : 125.0) : (rank == SILVER ? 100.0 : 75.0));
            float health_bonus = player2_lives * 25.0;
            player2->is_playing = false;
            player1->is_playing = false;
            player2->total_win += 1;
            player1->total_lose += 1;
            player2->changeRpAfterGame(delta_rp + health_bonus);
            player1->changeRpAfterGame(0 - delta_rp);
            player2->rankedGameEnded();
            player1->rankedGameEnded();
            in_progress = false;
            return;
        }
        return;
    }
}

void Ranked::processAction(Player* player, string action){
    if(isPlayerOne(player)){
        player1_moves.push_back(action);
        if(action == SHOOT){
            remaining_bullets_player1 -= 1;
            if(player1_moves.size() == player2_moves.size()){
                doAction();
                pending_turn += 1;
                return;
            }else{
                return;
            }
        }
        if(action == DEFEND){
            if(player1_moves.size() == player2_moves.size()){
                doAction();
                pending_turn += 1;
                return;
            }else{
                return;
            }
        }
        if(action == RELOAD){
            remaining_bullets_player1 += 1;
            if(player1_moves.size() == player2_moves.size()){
                doAction();
                pending_turn += 1;
                return;
            }else{
                return;
            }
        }
    }else{
        player2_moves.push_back(action);
        if(action == SHOOT){
            remaining_bullets_player2 -= 1;
            if(player2_moves.size() == player1_moves.size()){
                doAction();
                pending_turn += 1;
                return;
            }else{
                return;
            }
        }
        if(action == DEFEND){
            if(player2_moves.size() == player1_moves.size()){
                doAction();
                pending_turn += 1;
                return;
            }else{
                return;
            }
        }
        if(action == RELOAD){
            remaining_bullets_player2 += 1;
            if(player2_moves.size() == player1_moves.size()){
                doAction();
                pending_turn += 1;
                return;
            }else{
                return;
            }
        }
    }
}

string Ranked::makeLineForPrintHistory(string your_moves, string o_moves){
    string line = o_moves;
    while(line.length() != 20){
        line += " ";
    }
    line += your_moves;
    return line;
}

void Ranked::printMatchStatus(Player* player){
    string you;
    string your_o;
    string your_moves;
    string o_moves;
    if(isPlayerOne(player)){
        cout << "Turn " << pending_turn << endl; 
        if(player1_moves.size() == pending_turn){
            you = player1_moves[pending_turn - 1];
        }else{
            you = ISPENDING;
        }

        if(player2_moves.size() == pending_turn){
            your_o = ISPLAYED;
        }else{
            your_o = ISPENDING;
        }

        cout << "You: " << you << endl;
        cout << "Your opponent: " << your_o << endl;
        cout << "History:" << endl;
        cout << "Opponent's moves:   Your moves:" << endl;
        if(pending_turn != 1){
            for(int i=0; i< pending_turn - 1; i++){
                o_moves = player2_moves[i];
                your_moves = player1_moves[i];
                cout << makeLineForPrintHistory(your_moves, o_moves) << endl;
            }
        }
        cout << "Your remaining bullets: " << ((you == ISPENDING || you == DEFEND) ? remaining_bullets_player1 : (you == SHOOT ? remaining_bullets_player1 + 1 : remaining_bullets_player1 - 1)) << endl;
        cout << "Your remaining health: " << player1_lives << endl;
    }else{
        cout << "Turn " << pending_turn << endl; 
        if(player2_moves.size() == pending_turn){
            you = player2_moves[pending_turn - 1];
        }else{
            you = ISPENDING;
        }

        if(player1_moves.size() == pending_turn){
            your_o = ISPLAYED;
        }else{
            your_o = ISPENDING;
        }

        cout << "You: " << you << endl;
        cout << "Your opponent: " << your_o << endl;
        cout << "History:" << endl;
        cout << "Opponent's moves:   Your moves:" << endl;
        if(pending_turn != 1){
            for(int i=0; i< pending_turn - 1; i++){
                o_moves = player1_moves[i];
                your_moves = player2_moves[i];
                cout << makeLineForPrintHistory(your_moves, o_moves) << endl;
            }
        }
        cout << "Your remaining bullets: " << ((you == ISPENDING || you == DEFEND) ? remaining_bullets_player2  : (you == SHOOT ? remaining_bullets_player2 + 1 : remaining_bullets_player2 - 1)) << endl;
        cout << "Your remaining health: " << player2_lives << endl;
    }
}

void Ranked::applyPenalty(Player* player, Penalty* penalty){
    if(isPlayerOne(player)){
        if(penalty->num_of_match_bullet > 0){
            remaining_bullets_player1 -= penalty->am_bullet_pen;
            penalty->num_of_match_bullet -= 1;
        }
        if(penalty->num_of_match_health > 0){
            player1_lives -= penalty->am_health_pen;
            penalty->num_of_match_health -= 1;
        }
    }else{
        if(penalty->num_of_match_bullet > 0){
            remaining_bullets_player2 -= penalty->am_bullet_pen;
            penalty->num_of_match_bullet -= 1;
        }
        if(penalty->num_of_match_health > 0){
            player2_lives -= penalty->am_health_pen;
            penalty->num_of_match_health -= 1;
        }
    }
}