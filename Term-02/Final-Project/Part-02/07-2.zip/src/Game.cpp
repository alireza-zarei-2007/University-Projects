#include <vector>
#include <string>
#include <fstream>
#include <sstream>
#include <iostream>
#include <algorithm>
#include "../include/Game.hpp"

const int NUM_OF_FEATURE_PLAYER = 4;
const int NUM_OF_FEATURE_ADMIN = 2;

using namespace std;

Game::Game(): player_logged_in(nullptr), admin_logged_in(nullptr){}

void Game::addPlayer(string _username, string _password, float _xp, float _rp, bool is_from_file){
    if(is_from_file){//its for during the game
        Player* new_player = new Player(_username, _password, _xp, _rp);
        players.push_back(new_player);
        list_players_not_ready.push_back(new_player);
    }else{
        Player* new_player = new Player(_username, _password);
        players.push_back(new_player);
        list_players_not_ready.push_back(new_player);
        player_logged_in = new_player;
    }
}

void Game::addAdmin(string _username, string _password){
    Admin* new_admin = new Admin(_username, _password);
    admins.push_back(new_admin);
}

void Game::openReadCSVPlayers(string file_name){
    ifstream file(file_name);

    string line;
    getline(file, line);

    while(getline(file, line)){
        stringstream ss(line);
        string username;
        string password;
        float xp;
        float rp;
        string cell;

        for(int i=0; i<NUM_OF_FEATURE_PLAYER; i++){
            getline(ss, cell, ',');
            if(i==0) username = cell;
            if(i==1) password = cell;
            if(i==2) xp = stof(cell);
            if(i==3) rp = stof(cell);
        }

        addPlayer(username, password, xp, rp, true);
    }
}

void Game::openReadCSVAdmins(string file_name){
    ifstream file(file_name);

    string line;
    getline(file, line);

    while(getline(file, line)){
        stringstream ss(line);
        string username;
        string password;
        string cell;

        for(int i=0; i<NUM_OF_FEATURE_ADMIN; i++){
            getline(ss, cell, ',');
            if(i==0) username = cell;
            if(i==1) password = cell;
        }

        addAdmin(username, password);
    }
}

bool Game::isUserNameForPlayer(string _username){
    bool is_username_for_player = false;
    for(Player* player: players){
        if(player->getUserName() == _username) is_username_for_player = true;
    }
    return is_username_for_player;
}

bool Game::isUserNameForAdmin(string _username){
    bool is_username_for_admin = false;
    for(Admin* admin: admins){
        if(admin->getUserName() == _username) is_username_for_admin = true;
    }
    return is_username_for_admin;
}

bool Game::isUserNameExist(string _username){
    bool is_username_exist = false;
    for(Player* player: players){
        if(player->getUserName() == _username) is_username_exist = true;
    }
    for(Admin* admin: admins){
        if(admin->getUserName() == _username) is_username_exist = true;
    }
    return is_username_exist;
}

bool Game::isPassWordCorrect(string _username, string _password){
    for(Player* player: players){
        if(player->getUserName() == _username){
            return player->isMyPassWord(_password);
        }
    }
    for(Admin* admin: admins){
        if(admin->getUserName() == _username){
            return admin->isMyPassWord(_password);
        }
    }
}

void Game::login(string _username){
    for(Player* player: players){
        if(player->getUserName() == _username){
            player_logged_in = player;
        }
    }
    for(Admin* admin: admins){
        if(admin->getUserName() == _username){
            admin_logged_in = admin;
        }
    }
}

void Game::logout(){
    player_logged_in = nullptr;
    admin_logged_in = nullptr;
}

void Game::setStatusReady(bool status){
    player_logged_in->ready_to_play = status;
    auto it_ready = find(list_players_ready.begin(), list_players_ready.end(), player_logged_in);
    if(it_ready != list_players_ready.end()){
        list_players_ready.erase(it_ready);
    }
    auto it_not_ready = find(list_players_not_ready.begin(), list_players_not_ready.end(), player_logged_in);
    if(it_not_ready != list_players_not_ready.end()){
        list_players_not_ready.erase(it_not_ready);
    }

    if(status){
        list_players_ready.push_back(player_logged_in);
    }else{
        list_players_not_ready.push_back(player_logged_in);
    }
}

bool Game::isReadyPlayerEmpty(){
    vector<Player*> list_players_ready_copy = list_players_ready;
    auto it_ready = find(list_players_ready_copy.begin(), list_players_ready_copy.end(), player_logged_in);
    if(it_ready != list_players_ready_copy.end()){
        list_players_ready_copy.erase(it_ready);
    }

    return list_players_ready_copy.size() == 0;
}

void Game::sortByXpAndUserName(vector<Player*>& players_ready, string sort_order){
    if(sort_order == "desc"){
        sort(players_ready.begin(), players_ready.end(), 
            [](Player* a, Player* b){
                if(a->getXp() != b->getXp()){
                    return a->getXp() > b->getXp();
                }
                return a->getUserName() < b->getUserName();
            });
    }
    if(sort_order == "asc"){
        sort(players_ready.begin(), players_ready.end(), 
            [](Player* a, Player* b){
                if(a->getXp() != b->getXp()){
                    return a->getXp() < b->getXp();
                }
                return a->getUserName() < b->getUserName();
            });
    }
}

void Game::sortByRpAndUserName(vector<Player*>& same_level_players, string sort_order){
    if(sort_order == "desc"){
        sort(same_level_players.begin(), same_level_players.end(), 
            [](Player* a, Player* b){
                if(a->getRp() != b->getRp()){
                    return a->getRp() > b->getRp();
                }
                return a->getUserName() < b->getUserName();
            });
    }

    if(sort_order == "asc"){
        sort(same_level_players.begin(), same_level_players.end(), 
            [](Player* a, Player* b){
                if(a->getRp() != b->getRp()){
                    return a->getRp() < b->getRp();
                }
                return a->getUserName() < b->getUserName();
            });
    }
}

void Game::printReadyPlayer(string sort_order){
    vector<Player*> list_players_ready_copy = list_players_ready;
    auto it_ready = find(list_players_ready_copy.begin(), list_players_ready_copy.end(), player_logged_in);
    if(it_ready != list_players_ready_copy.end()){
        list_players_ready_copy.erase(it_ready);
    }

    sortByXpAndUserName(list_players_ready_copy, sort_order);

    for(int i=0; i<list_players_ready_copy.size(); i++){
        cout << i+1 << ". " << list_players_ready_copy[i]->getUserName() << " with " << list_players_ready_copy[i]->getXp() << " XP" << endl;
    }
}

Player* Game::getPlayerByUserName(string _username){
    for(Player* player: players){
        if(player->getUserName() == _username) return player;
    }
    return nullptr;
}

void Game::setInvitation(string receiver_name, string game_type){
    int user_level_id = player_logged_in->getNewInvitationId();
    int app_level_id = invitations.size() + 1;
    string sender_name = player_logged_in->getUserName();
    if(game_type == "casual"){
        Invitation* new_invitation = new Invitation(receiver_name, sender_name, app_level_id, user_level_id, CASUAL);
        Player* sender = player_logged_in;
        Player* receiver = getPlayerByUserName(receiver_name);

        sender->addSentInvitation(new_invitation);
        receiver->addReceivedInvitation(new_invitation);
        invitations.push_back(new_invitation);
    }
    if(game_type == "ranked"){
        Invitation* new_invitation = new Invitation(receiver_name, sender_name, app_level_id, user_level_id, RANKED);
        Player* sender = player_logged_in;
        Player* receiver = getPlayerByUserName(receiver_name);

        sender->addSentInvitation(new_invitation);
        receiver->addReceivedInvitation(new_invitation);
        invitations.push_back(new_invitation);
    }
    
}

Invitation* Game::getInvitationById(int id){
    for(Invitation* invitation: invitations){
        if(invitation->app_level_id == id) return invitation;
    }
    return nullptr;
}

void Game::setInvitationAccepted(int id){
    Invitation* target_invitation = getInvitationById(id);
    target_invitation->my_status = ACCEPTED;
}

void Game::setInvitationRejected(int id){
    Invitation* target_invitation = getInvitationById(id);
    target_invitation->my_status = REJECTED;
}

void Game::applyPenaltyForPlayers(Player* player1, Player* player2, Ranked* new_ranked){
    if(player1->my_pen != nullptr){
        new_ranked->applyPenalty(player1, player1->my_pen);
    }
    if (player1->my_pen != nullptr 
        && player1->my_pen->num_of_match_bullet == 0 
        && player1->my_pen->num_of_match_health == 0) {
        player1->my_pen = nullptr;
    }

    if(player2->my_pen != nullptr){
        new_ranked->applyPenalty(player2, player2->my_pen);
    }
    if (player2->my_pen != nullptr 
        && player2->my_pen->num_of_match_bullet == 0 
        && player2->my_pen->num_of_match_health == 0) {
        player2->my_pen = nullptr;
    }
}

void Game::createNewGameAndAddPlayers(Player* player1, Player* player2, gamet game_type){
    if(game_type == CASUAL){
        Casual* new_casual = new Casual(player1, player2);
        player1->joinGame(new_casual, nullptr);
        player2->joinGame(new_casual, nullptr);
        casual_games.push_back(new_casual);
    }

    if(game_type == RANKED){
        Ranked* new_ranked = new Ranked(player1, player2);
        player1->joinGame(nullptr, new_ranked);
        player2->joinGame(nullptr, new_ranked);
        ranked_games.push_back(new_ranked);
        applyPenaltyForPlayers(player1, player2, new_ranked);
    }
}

void Game::setReport(string reported_username, string reason){
    string sender_username = player_logged_in->getUserName();
    int app_level_id = reports.size() + 1;
    int user_level_id = player_logged_in->getNewReportId();
    Report* new_report = new Report(reason, reported_username, sender_username, app_level_id, user_level_id);
    player_logged_in->addSentReport(new_report);
    reports.push_back(new_report);
}

void Game::printProfile(string _username){
    Player* target_player = getPlayerByUserName(_username);
    rlevel lev = target_player->rank_level;
    string my_level = (lev == PLATINUM || lev == GOLD) ? (lev == PLATINUM ? "Platinum" : "Golden") : (lev == SILVER ? "Silver" : "Bronze");
    cout << "username: " << '"' <<_username << '"' << endl;
    cout << "Level: " << my_level << endl;
    cout << "RP: " << target_player->getRp() << endl;
    cout << "XP: " << target_player->getXp() << endl;
    cout << "Total wins: " << target_player->total_win << endl;
    cout << "Total losses: " << target_player->total_lose << endl;
}

bool Game::isReportsEmpty(){
    for(int i=0; i<reports.size(); i++){
        if(reports[i]->my_status == OPEN) return false;
    }
    return true;
}

void Game::printReports(){
    for(Report* report : reports){
        if(report->my_status == OPEN){
            int id = report->app_level_id;
            string sender = '"' + report->sender_username + '"';
            string reported = '"' + report->reported_username + '"';
            string reason = '"' + report->reason + '"';
            cout << id << ": " << sender << " reported " << reported << " for: " << reason << endl;
        }
    }
}

bool Game::isSameLevelPlayerEmpty(){
    rlevel target_level = player_logged_in->rank_level;
    vector<Player*> same_level_players = players;
    same_level_players.erase(remove_if(same_level_players.begin(), same_level_players.end(),
                             [=](Player* x){ return (x->rank_level != target_level) || (x == player_logged_in); }
                            ),
                            same_level_players.end()
                        );
    return same_level_players.size() == 0;
}

void Game::printSameLevelPlayer(string sort_order){
    rlevel target_level = player_logged_in->rank_level;
    vector<Player*> same_level_players = players;
    same_level_players.erase(remove_if(same_level_players.begin(), same_level_players.end(),
                             [=](Player* x){ return (x->rank_level != target_level) || (x == player_logged_in); }
                            ),
                            same_level_players.end()
                        );

    sortByRpAndUserName(same_level_players, sort_order);

    for(int i=0; i<same_level_players.size(); i++){
        cout << i+1 << ". " << same_level_players[i]->getUserName() << " with " << same_level_players[i]->getRp() << " RP" << endl;
    }
}

void Game::processBlockPlayer(string username, string status_block){
    Player* target_player = getPlayerByUserName(username);
    if(status_block == "blocked"){
        target_player->addPlayerBlockMe(player_logged_in);
    }
    if(status_block == "unblocked"){
        target_player->removePlayerBlockMe(player_logged_in);
    }
}

bool Game::isReportOpen(int report_id){
    for(int i=0; i<reports.size(); i++){
        if(reports[i]->app_level_id == report_id){
            return reports[i]->my_status == OPEN;
        }
    }
    return false;
}

void Game::setPenalty(int report_id, string types, int amount, int num_of_matches){
    Report* target_report;
    for(int i=0; i<reports.size(); i++){
        if(reports[i]->app_level_id == report_id) target_report = reports[i];
    }
    Player* target_player = getPlayerByUserName(target_report->reported_username);
    pent penalty_type = (types == "health_penalty" ? HEALTH : BULLET);
    if(target_player->my_pen == nullptr){
        Penalty* new_penalty = new Penalty(amount, num_of_matches, penalty_type);
        target_player->my_pen = new_penalty;
        target_report->my_status = CLOSED;
        return;
    }
    if(target_player->my_pen != nullptr){
        target_player->my_pen->changeInformationPen(amount, num_of_matches, penalty_type);
        target_report->my_status = CLOSED;
        return;
    }
}

void Game::reportClosed(int report_id){
    for(Report* report : reports){
        if(report->app_level_id == report_id){
            report->my_status = CLOSED;
        }
    }
}