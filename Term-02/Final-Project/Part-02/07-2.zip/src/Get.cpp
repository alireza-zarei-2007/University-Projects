#include "../include/Get.hpp"
#include <iostream>

const string OK = "OK";
const string EMPTY = "Empty";
const string NOT_FOUND = "Not Found";
const string BAD_REQUEST = "Bad Request";
const string PERMISSION_DENIED = "Permission Denied";

const string ASC = "asc";
const string DESC = "desc";

Get::Get(vector<string> _commnads_noun, string _command_verb): Command(_commnads_noun, _command_verb){}

void Get::printOk() { cout << OK << endl; }

void Get::printEmptyError() { cout << EMPTY << endl; }

void Get::printNotFoundError() { cout << NOT_FOUND << endl; }

void Get::printBadRequestError() { cout << BAD_REQUEST << endl; }

void Get::printPermissionDeniedError() { cout << PERMISSION_DENIED << endl; }

bool Get::generalCheckSyn(string _arguments){
    string word_key;
    string word_value;
    stringstream ss(_arguments);
    while(ss >> word_key){
        if(isCommandSynTrue(word_key)){
            return false;
        }
        if(ss >> word_value){
            if(!isCommandSynTrue(word_value)){
                return false;
            }
        }else{
            return false;
        }
    }
    return true;
}

bool Get::isMyCommandNoun(string cmd_noun){
    bool is_my_command_noun = false;
    for(string noun: commnads_noun){
        if(cmd_noun == noun){
            is_my_command_noun = true;
        }
    }
    return is_my_command_noun;
}

bool Get::isCommandSynTrue(string word){
    if(word.front() == '"' && word.back() == '"' && word.length() >= 2){
        return true;
    }
    return false;
}

bool Get::isSortOrderSynTrue(string& sort_order, string word){
    word = word.substr(1, word.length() - 2);
    if(word == ASC){
        sort_order = ASC;
        return true;
    }else if(word == DESC){
        sort_order = DESC;
        return true;
    }else{
        return false;
    }
}

bool Get::hasErrorCMOpponents(Game& game, string _arguments, bool is_sort_order_writed, bool is_command_syn_true, bool is_sort_order_syn_true){
    if(!generalCheckSyn(_arguments)){
        printBadRequestError();
        return true;
    }

    if(is_sort_order_writed && !is_command_syn_true){
        printBadRequestError();
        return true;
    }

    if((game.admin_logged_in != nullptr) || (game.admin_logged_in == nullptr && game.player_logged_in == nullptr)){
        printPermissionDeniedError();
        return true;
    }

    if(is_sort_order_writed && !is_sort_order_syn_true){
        printBadRequestError();
        return true;
    }

    if(game.isReadyPlayerEmpty()){
        printEmptyError();
        return true;
    }

    return false;
}

void Get::checkArgumentsCMOpponentsAndProcess(Game& game, string _arguments){
    string sort_order = DESC;
    string word_key;
    string word_value;
    bool is_sort_order_writed = false;
    bool is_command_syn_true = false;
    bool is_sort_order_syn_true = false;

    stringstream ss(_arguments);
    while(ss >> word_key){
        if(word_key == "sort_order"){
            is_sort_order_writed = true;
            if(ss >> word_value){
                is_command_syn_true = isCommandSynTrue(word_value);
                if(is_command_syn_true){
                    is_sort_order_syn_true = isSortOrderSynTrue(sort_order, word_value);
                }
            }
        }
        if(is_sort_order_writed && is_command_syn_true && is_sort_order_syn_true){
            break;
        }
    }

    if(hasErrorCMOpponents(game, _arguments, is_sort_order_writed, is_command_syn_true, is_sort_order_syn_true)) return;

    game.printReadyPlayer(sort_order);
}

bool Get::hasErrorMatchStatus(Game& game, string _arguments){
    if(!generalCheckSyn(_arguments)){
        printBadRequestError();
        return true;
    }

    if((game.admin_logged_in != nullptr) || (game.admin_logged_in == nullptr && game.player_logged_in == nullptr)){
        printPermissionDeniedError();
        return true;
    }

    if(!game.player_logged_in->is_playing){
        printNotFoundError();
        return true;
    }

    return false;
}

void Get::checkArgumentsMatchStatusAndProcess(Game& game, string _arguments){
    if(hasErrorMatchStatus(game, _arguments)) return;

    if(game.player_logged_in->get_current_game_casual() != nullptr){
        Casual* current_game_casual = game.player_logged_in->get_current_game_casual();
        current_game_casual->printMatchStatus(game.player_logged_in);
        return;
    }
    if(game.player_logged_in->get_current_game_ranked() != nullptr){
        Ranked* current_game_ranked = game.player_logged_in->get_current_game_ranked();
        current_game_ranked->printMatchStatus(game.player_logged_in);
        return;
    }
}

void Get::setValueOnObject(string& object, string word){
    word = word.substr(1, word.length() - 2);
    object = word;
}

bool Get::hasErrorProfile(Game& game, bool is_username_exist, string& username_value){
    if(game.admin_logged_in == nullptr && game.player_logged_in == nullptr){
        printPermissionDeniedError();
        return true;
    }

    if((!is_username_exist) && (game.admin_logged_in != nullptr)){
        printPermissionDeniedError();
        return true;
    }

    if(!is_username_exist){
        username_value = game.player_logged_in->getUserName();
    }

    if(!game.isUserNameExist(username_value)){
        printNotFoundError();
        return true;
    }

    if(game.isUserNameForAdmin(username_value)){
        printPermissionDeniedError();
        return true;
    }

    return false;
}

void Get::checkArgumentsProfileAndProcess(Game& game, string _arguments){
    string username_value;
    string word_key;
    string word_value;
    bool is_username_exist = false;

    if(!generalCheckSyn(_arguments)){
        printBadRequestError();
        return;
    }

    stringstream ss(_arguments);
    
    while(ss >> word_key){
        if(word_key == "username"){
            ss >> word_value;
            setValueOnObject(username_value, word_value);
            is_username_exist = true;
        }
    }
    
    if(hasErrorProfile(game, is_username_exist, username_value)) return;
    
    game.printProfile(username_value);
    
}

bool Get::hasErrorPrintInvitations(Game& game, string _arguments){
    if(!generalCheckSyn(_arguments)){
        printBadRequestError();
        return true;
    }

    if((game.admin_logged_in != nullptr) || (game.admin_logged_in == nullptr && game.player_logged_in == nullptr)){
        printPermissionDeniedError();
        return true;
    }

    if(game.player_logged_in->isReceivedInvitationsEmpty()){
        printEmptyError();
        return true;
    }

    return false;
}

void Get::checkArgumentsPrintInvitationsAndProcess(Game& game, string _arguments){
    if(hasErrorPrintInvitations(game, _arguments)) return;

    game.player_logged_in->printReceivedInvitations();
}

bool Get::hasErrorPrintReports(Game& game, string _arguments){
    if(!generalCheckSyn(_arguments)){
        printBadRequestError();
        return true;
    }

    if((game.player_logged_in != nullptr) || (game.admin_logged_in == nullptr && game.player_logged_in == nullptr)){
        printPermissionDeniedError();
        return true;
    }

    if(game.isReportsEmpty()){
        printEmptyError();
        return true;
    }

    return false;
}

void Get::checkArgumentsPrintReportsAndProcess(Game& game, string _arguments){
    if(hasErrorPrintReports(game, _arguments)) return;

    game.printReports();
}

bool Get::hasErrorRMOpponents(Game& game, string _arguments, bool is_sort_order_writed, bool is_command_syn_true, bool is_sort_order_syn_true){
    if(!generalCheckSyn(_arguments)){
        printBadRequestError();
        return true;
    }

    if(is_sort_order_writed && !is_command_syn_true){
        printBadRequestError();
        return true;
    }

    if((game.admin_logged_in != nullptr) || (game.admin_logged_in == nullptr && game.player_logged_in == nullptr)){
        printPermissionDeniedError();
        return true;
    }

    if(is_sort_order_writed && !is_sort_order_syn_true){
        printBadRequestError();
        return true;
    }

    if(game.isSameLevelPlayerEmpty()){
        printEmptyError();
        return true;
    }

    return false;

}

void Get::checkArgumentsRMOpponentsAndProcess(Game& game, string _arguments){
    string sort_order = DESC;
    string word_key;
    string word_value;
    bool is_sort_order_writed = false;
    bool is_command_syn_true = false;
    bool is_sort_order_syn_true = false;

    stringstream ss(_arguments);
    while(ss >> word_key){
        if(word_key == "sort_order"){
            is_sort_order_writed = true;
            if(ss >> word_value){
                is_command_syn_true = isCommandSynTrue(word_value);
                if(is_command_syn_true){
                    is_sort_order_syn_true = isSortOrderSynTrue(sort_order, word_value);
                }
            }
        }
        if(is_sort_order_writed && is_command_syn_true && is_sort_order_syn_true){
            break;
        }
    }

    if(hasErrorRMOpponents(game, _arguments, is_sort_order_writed, is_command_syn_true, is_sort_order_syn_true)) return;

    game.printSameLevelPlayer(sort_order);
}