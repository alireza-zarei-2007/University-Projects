#ifndef ENUM_HPP
#define ENUM_HPP

namespace invitestatus {
    enum status {ACCEPTED, REJECTED, PENDING};
}

namespace reportstatus {
    enum rstatus {OPEN, CLOSED};
}

namespace level {
    enum rlevel {BRONZE, SILVER, GOLD, PLATINUM};
}

namespace type {
    enum gamet {CASUAL, RANKED};
    enum pent {HEALTH, BULLET};
}

#endif