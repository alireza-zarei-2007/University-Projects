 #ifndef POST_HPP
#define POST_HPP
#include <iostream>
#include "Command.hpp"
#include "Game.hpp"




class Post: public Command {
public:
    Post(vector<string> _commnads_noun, string _command_verb);
    bool isMyCommandNoun(string cmd_noun);
    void checkArgumentsRegisterAndProcess(Game& game, string arguments);
    void checkArgumentsLoginAndProcess(Game& game, string arguments);
    void checkArgumentsLogOutAndProcess(Game& game, string arguments);
    void checkArgumentsCMReadyAndProcess(Game& game, string arguments);
    void checkArgumentsInviteAndProcess(Game& game, string arguments);
    void checkArgumentsRejInviteAndProcess(Game& game, string arguments);
    void checkArgumentsStartMatchAndProcess(Game& game, string arguments);
    void checkArgumentsActionAndProcess(Game& game, string arguments);
    void checkArgumentsReportAndProcess(Game& game, string arguments);
    void checkArgumentsBlockAndProcess(Game& game, string arguments);
    void checkArgumentsPenaltyAndProcess(Game& game, string arguments);
    void checkArgumentsDismissReportAndProcess(Game& game, string arguments);
private:
    void printOk();
    void printEmptyError();
    void printNotFoundError();
    void printBadRequestError();
    void printPermissionDeniedError();
    bool isUserNameFind(string& username, string word);
    bool isPassWordFind(string& password, string word);
    bool isCommandSynTrue(string word);
    bool isStatusSynTrue(bool& status, string word);
    void setValueOnObject(string& object, string word);
    bool generalCheckSyn(string arguments);
    bool isActionSynTrue(string word);
    bool isBlank(string line);
    bool isAllArgumentsPenaltyFound(bool report, bool types, bool amount, bool matches);
    bool isNumber(string line);
    bool hasErrorRegister(Game& game, string _arguments, bool is_username_find, bool is_password_find, string username);
    bool hasErrorLogin(Game& game, string _arguments, bool is_username_find, bool is_password_find, string username, string password);
    bool hasErrorCMReady(Game& game, string _arguments, bool is_command_syn_true, bool is_status_syn_true);
    bool hasErrorInvite(Game& game, string _arguments, bool is_command_syn_true1, bool is_command_syn_true2
                        , string username, string match_type);
};

#endif