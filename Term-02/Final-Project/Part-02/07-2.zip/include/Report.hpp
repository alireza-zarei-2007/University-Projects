#ifndef REPORT_HPP
#define REPORT_HPP
#include <string>
#include "enum.hpp"

using namespace std;
using namespace reportstatus;

class Report {
public:
    Report(string _reason, string _reported_username, string _sender_username, int _app_level_id, int _user_level_id);
    int app_level_id;
    int user_level_id;
    string reason;
    string reported_username;
    string sender_username;
    rstatus my_status;
};

#endif