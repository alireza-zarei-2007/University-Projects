#ifndef RANKED_HPP
#define RANKED_HPP
#include <string>
#include <iostream>
#include "Player.hpp"

using namespace std;

class Player;
class Penalty;

class Ranked {
public:
    Ranked(Player* _player1, Player* _player2);
    bool canPlayerMove(Player* player);
    bool hasEnoughBullets(Player* player);
    void processAction(Player* player, string action);
    void applyPenalty(Player* player, Penalty* penalty);
    void printMatchStatus(Player* player);

private:
    bool isPlayerOne(Player* player);
    void doAction();
    string makeLineForPrintHistory(string your_moves, string o_moves);

    Player* player1;
    Player* player2;
    bool in_progress;
    vector<string> player1_moves;
    vector<string> player2_moves;
    int pending_turn;
    int remaining_bullets_player1;
    int remaining_bullets_player2;
    int player1_lives;
    int player2_lives;
};

#endif