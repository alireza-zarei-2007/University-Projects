#ifndef GET_HPP
#define GET_HPP
#include "Command.hpp"
#include "Game.hpp"

class Get: public Command {
public:
    Get(vector<string> _commnads_noun, string _command_verb);
    void checkArgumentsCMOpponentsAndProcess(Game& game, string arguments);
    void checkArgumentsMatchStatusAndProcess(Game& game, string arguments);
    void checkArgumentsProfileAndProcess(Game& game, string arguments);
    void checkArgumentsPrintInvitationsAndProcess(Game& game, string arguments);    
    void checkArgumentsPrintReportsAndProcess(Game& game, string arguments);    
    void checkArgumentsRMOpponentsAndProcess(Game& game, string arguments);    
    bool isMyCommandNoun(string cmd_noun);

private:
    void printOk();
    void printEmptyError();
    void printNotFoundError();
    void printBadRequestError();
    void printPermissionDeniedError();
    bool isCommandSynTrue(string word);
    bool isSortOrderSynTrue(string& sort_order, string word);
    bool generalCheckSyn(string arguments);
    void setValueOnObject(string& object, string word);
    bool hasErrorCMOpponents(Game& game, string _arguments, bool is_sort_order_writed, bool is_command_syn_true, bool is_sort_order_syn_true);
    bool hasErrorMatchStatus(Game& game, string _arguments);
    bool hasErrorProfile(Game& game, bool is_username_exist, string& username_value);
    bool hasErrorPrintInvitations(Game& game, string _arguments);
    bool hasErrorPrintReports(Game& game, string _arguments);
    bool hasErrorRMOpponents(Game& game, string _arguments, bool is_sort_order_writed, bool is_command_syn_true, bool is_sort_order_syn_true);
    
};

#endif