#ifndef GAME_HPP
#define GAME_HPP
#include <string>
#include <vector>
#include "Player.hpp"
#include "Admin.hpp"
#include "Invitation.hpp"

using namespace std;

class Game {
public:
    Game();
    void openReadCSVPlayers(string file_name);
    void openReadCSVAdmins(string file_name);
    bool isUserNameExist(string username);
    bool isUserNameForPlayer(string username);
    bool isUserNameForAdmin(string username);
    bool isPassWordCorrect(string username, string password);
    void addPlayer(string _username, string _password, float _xp, float _rp, bool is_from_file);
    void login(string username);
    void logout();
    void setStatusReady(bool status);
    bool isReadyPlayerEmpty();
    bool isSameLevelPlayerEmpty();
    void printReadyPlayer(string sort_order);
    void printSameLevelPlayer(string sort_order);
    void setInvitation(string receiver_name, string game_type);
    void setInvitationAccepted(int id);
    void setInvitationRejected(int id);
    void createNewGameAndAddPlayers(Player* player1, Player* player2, gamet game_type);
    void applyPenaltyForPlayers(Player* player1, Player* player2, Ranked* new_ranked);
    void setReport(string reported_username, string reason);
    void printProfile(string _username);
    bool isReportsEmpty();
    void printReports();
    void processBlockPlayer(string username, string status_block);
    bool isReportOpen(int report_id);
    void setPenalty(int report_id, string types, int amount, int num_of_matches);
    void reportClosed(int report_id);
    Player* getPlayerByUserName(string username);
    Invitation* getInvitationById(int id);
    
    Player* player_logged_in;
    Admin* admin_logged_in;
    
private:
    vector<Player*> players;
    vector<Admin*> admins;
    vector<Player*> list_players_ready;
    vector<Player*> list_players_not_ready;
    vector<Invitation*> invitations;
    vector<Report*> reports;
    vector<Casual*> casual_games;
    vector<Ranked*> ranked_games;

    
    void addAdmin(string _username, string _password);
    void sortByXpAndUserName(vector<Player*>& players_ready, string sort_order);
    void sortByRpAndUserName(vector<Player*>& same_level_players, string sort_order);
};

#endif