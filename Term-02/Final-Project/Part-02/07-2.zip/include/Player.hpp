#ifndef PLAYER_HPP
#define PLAYER_HPP
#include <vector>
#include <string>
#include <algorithm>
#include "Member.hpp"
#include "Invitation.hpp"
#include "Casual.hpp"
#include "Ranked.hpp"
#include "Report.hpp"
#include "Penalty.hpp"

using namespace level;

class Casual;
class Ranked;

class Player : public Member {
public:
    Player(string _username, string _password);
    Player(string _username, string _password, float _xp, float _rp);
    int getNewInvitationId();
    int getNewReportId();
    void addSentReport(Report* new_report);
    float getXp();
    float getRp();
    void addSentInvitation(Invitation* new_invitation);
    void addReceivedInvitation(Invitation* new_invitation);
    bool isReceivedInvitationExistAndPending(int invite_id);
    void joinGame(Casual* game_casual, Ranked* game_ranked);
    Casual* get_current_game_casual();
    Ranked* get_current_game_ranked();
    void changeXpAfterGame(float delta_xp);
    void changeRpAfterGame(float delta_rp);
    void casualGameEnded();
    void rankedGameEnded();
    bool isReceivedInvitationsEmpty();
    void printReceivedInvitations();
    void addPlayerBlockMe(Player* player_blocked_me);
    void removePlayerBlockMe(Player* player_blocked_me);
    bool isThisPlayerBlockedMe(Player* target_player);
    bool ready_to_play;
    bool is_playing;
    int total_win;
    int total_lose;
    rlevel rank_level;
    Penalty* my_pen;
    
private:
    void updateRank();
    float xp;
    float rp;
    vector<Invitation*> received_invitations;
    vector<Invitation*> sent_invitations;
    vector<Report*> sent_reports;
    Casual* current_game_casual;
    Ranked* current_game_ranked;
    vector <Player*> players_blocked_me;
};

#endif