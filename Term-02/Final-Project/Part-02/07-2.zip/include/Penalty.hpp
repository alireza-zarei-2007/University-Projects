#ifndef PENALTY_HPP
#define PENALTY_HPP
#include <string>
#include "enum.hpp"

using namespace type;
using namespace std;

class Penalty {
public:
    Penalty(int amount, int num_of_match, pent penalty_type);
    int am_health_pen;
    int am_bullet_pen;
    int num_of_match_health;
    int num_of_match_bullet;    

    void changeInformationPen(int amount, int num_of_match, pent penalty_type);
};

#endif