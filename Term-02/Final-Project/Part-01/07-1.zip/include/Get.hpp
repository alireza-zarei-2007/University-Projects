#ifndef GET_HPP
#define GET_HPP
#include "Command.hpp"
#include "Game.hpp"

class Get: public Command {
public:
    Get(vector<string> _commnads_noun, string _command_verb);
    void checkArgumentsCMOpponentsAndProcess(Game& game, string arguments);
    void checkArgumentsMatchStatusAndProcess(Game& game, string arguments);
    void checkArgumentsProfileAndProcess(Game& game, string arguments);
    void checkArgumentsPrintInvitationsAndProcess(Game& game, string arguments);    
    void checkArgumentsPrintReportsAndProcess(Game& game, string arguments);    
    bool isMyCommandNoun(string cmd_noun);

private:
    bool isCommandSynTrue(string word);
    bool isSortOrderSynTrue(string& sort_order, string word);
    bool generalCheckSyn(string arguments);
    void setValueOnObject(string& object, string word);


    
};

#endif