#ifndef ADMIN_HPP
#define ADMIN_HPP
#include "Member.hpp"

class Admin : public Member {
public:
    Admin(string _username, string _password);
private:

};

#endif