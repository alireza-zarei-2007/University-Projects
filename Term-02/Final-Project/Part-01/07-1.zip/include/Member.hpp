#ifndef MEMBER_HPP
#define MEMBER_HPP
#include <string>
#include <sstream>

using namespace std;

class Member {
public:
    Member (string _username, string _password);
    string getUserName();
    bool isMyPassWord(string password);
protected:
    string username;
    string password;
    
    
};

#endif