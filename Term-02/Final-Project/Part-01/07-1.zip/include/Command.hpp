#ifndef COMMAND_HPP
#define COMMAND_HPP
#include <string>
#include <vector>

using namespace std;

class Command {
public:
    Command(vector<string> _commnads_noun, string _command_verb);

protected:
    vector<string> commnads_noun;
    string command_verb;

};

#endif