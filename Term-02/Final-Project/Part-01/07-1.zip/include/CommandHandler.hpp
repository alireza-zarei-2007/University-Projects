#ifndef COMMANDHANDLER_HPP
#define COMMANDHANDLER_HPP
#include "Game.hpp"
#include "Post.hpp"
#include "Get.hpp"
#include "Put.hpp"
#include "Delete.hpp"

class CommandHandler {
public:
    CommandHandler(Game& game);
    void run();

private:
    Game& game;
    void processCommand(string line);
    void processCommandNoun(Get get, Post post, string cmd, string cmd_noun, string arguments);
};

#endif