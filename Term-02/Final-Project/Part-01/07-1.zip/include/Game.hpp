#ifndef GAME_HPP
#define GAME_HPP
#include <string>
#include <vector>
#include "Player.hpp"
#include "Admin.hpp"
#include "Invitation.hpp"

using namespace std;

class Game {
public:
    Game();
    void openReadCSVPlayers(string file_name);
    void openReadCSVAdmins(string file_name);
    bool isUserNameExist(string username);
    bool isUserNameForPlayer(string username);
    bool isUserNameForAdmin(string username);
    bool isPassWordCorrect(string username, string password);
    void addPlayer(string _username, string _password, float _xp, bool is_from_file);
    void login(string username);
    void logout();
    void setStatusReady(bool status);
    bool isReadyPlayerEmpty();
    void printReadyPlayer(string sort_order);
    void setInvitation(string receiver_name, string game_type);
    void setInvitationAccepted(int id);
    void setInvitationRejected(int id);
    void createNewGameAndAddPlayers(Player* player1, Player* player2, gamet game_type);
    void setReport(string reported_username, string reason);
    void printProfile(string _username);
    bool isReportsEmpty();
    void printReports();
    Player* getPlayerByUserName(string username);
    Invitation* getInvitationById(int id);
    
    Player* player_logged_in;
    Admin* admin_logged_in;
    
private:
    vector<Player*> players;
    vector<Admin*> admins;
    vector<Player*> list_players_ready;
    vector<Player*> list_players_not_ready;
    vector<Invitation*> invitations;
    vector<Report*> reports;
    vector<Casual*> casual_games;

    
    void addAdmin(string _username, string _password);
    void sortByXpAndUserName(vector<Player*>& players_ready, string sort_order);
};

#endif