#ifndef ENUM_HPP
#define ENUM_HPP

namespace invitestatus {
    enum status {ACCEPTED, REJECTED, PENDING};
}

namespace gametype {
    enum gamet {CASUAL};
}

#endif