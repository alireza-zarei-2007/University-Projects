#ifndef DELETE_HPP
#define DELETE_HPP
#include "Command.hpp"
#include "Game.hpp"

class Delete: public Command {
public:
    Delete(vector<string> _commnads_noun, string _command_verb);
private:


    
};

#endif