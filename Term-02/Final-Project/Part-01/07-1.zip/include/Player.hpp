#ifndef PLAYER_HPP
#define PLAYER_HPP
#include <vector>
#include <string>
#include "Member.hpp"
#include "Invitation.hpp"
#include "Casual.hpp"
#include "Report.hpp"

class Casual;

class Player : public Member {
public:
    Player(string _username, string _password);
    Player(string _username, string _password, float _xp);
    int getNewInvitationId();
    int getNewReportId();
    void addSentReport(Report* new_report);
    int getXp();
    void addSentInvitation(Invitation* new_invitation);
    void addReceivedInvitation(Invitation* new_invitation);
    bool isReceivedInvitationExistAndPending(int invite_id);
    void joinGame(Casual* game);
    Casual* get_current_game_casual();
    void changeXpAfterGame(float delta_xp);
    void casualGameEnded();
    bool isReceivedInvitationsEmpty();
    void printReceivedInvitations();
    bool ready_to_play;
    bool is_playing;
    int total_win;
    int total_lose;
    
private:
    float xp;
    vector<Invitation*> received_invitations;
    vector<Invitation*> sent_invitations;
    vector<Report*> sent_reports;
    Casual* current_game_casual;

};

#endif