#ifndef PUT_HPP
#define PUT_HPP
#include "Command.hpp"
#include "Game.hpp"

class Put: public Command {
public:
    Put(vector<string> _commnads_noun, string _command_verb);
private:


    
};

#endif