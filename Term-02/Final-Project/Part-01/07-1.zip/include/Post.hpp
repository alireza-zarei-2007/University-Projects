#ifndef POST_HPP
#define POST_HPP
#include <iostream>
#include "Command.hpp"
#include "Game.hpp"




class Post: public Command {
public:
    Post(vector<string> _commnads_noun, string _command_verb);
    bool isMyCommandNoun(string cmd_noun);
    void checkArgumentsRegisterAndProcess(Game& game, string arguments);
    void checkArgumentsLoginAndProcess(Game& game, string arguments);
    void checkArgumentsLogOutAndProcess(Game& game, string arguments);
    void checkArgumentsCMReadyAndProcess(Game& game, string arguments);
    void checkArgumentsInviteAndProcess(Game& game, string arguments);
    void checkArgumentsRejInviteAndProcess(Game& game, string arguments);
    void checkArgumentsStartMatchAndProcess(Game& game, string arguments);
    void checkArgumentsActionAndProcess(Game& game, string arguments);
    void checkArgumentsReportAndProcess(Game& game, string arguments);
private:
    bool isUserNameFind(string& username, string word);
    bool isPassWordFind(string& password, string word);
    bool isCommandSynTrue(string word);
    bool isStatusSynTrue(bool& status, string word);
    void setValueOnObject(string& object, string word);
    bool generalCheckSyn(string arguments);
    bool isActionSynTrue(string word);
    bool isBlank(string line);
};

#endif