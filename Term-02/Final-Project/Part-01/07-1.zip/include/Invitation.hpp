#ifndef INVITATION_HPP
#define INVITATION_HPP
#include <string>
#include "enum.hpp"

using namespace std;
using namespace invitestatus;
using namespace gametype;

class Invitation {
public:
    Invitation(string _receiver, string _sender, int _app_level_id, int _user_level_id, gamet _game_type);
    string get_sender_name();
    gamet get_game_type();
    status my_status;
    int app_level_id;
    int user_level_id;

private:
    string receiver;
    string sender;
    gamet game_type;
    
};


#endif