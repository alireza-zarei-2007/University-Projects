#ifndef CASUAL_HPP
#define CASUAL_HPP
#include <string>
#include <iostream>
#include "Player.hpp"

const string SHOOT = "shoot";
const string DEFEND = "defend";
const string RELOAD = "reload";
const string ISPENDING = "pending";
const string PLAYED = "played";

using namespace std;

class Player;

class Casual {
public:
    Casual(Player* _player1, Player* _player2);
    bool canPlayerMove(Player* player);
    bool hasEnoughBullets(Player* player);
    void processAction(Player* player, string action);
    void printMatchStatus(Player* player);

private:
    bool isPlayerOne(Player* player);
    void doAction();
    string makeLineForPrintHistory(string your_moves, string o_moves);

    Player* player1;
    Player* player2;
    bool in_progress;
    vector<string> player1_moves;
    vector<string> player2_moves;
    int pending_turn;
    int remaining_bullets_player1;
    int remaining_bullets_player2;
};


#endif