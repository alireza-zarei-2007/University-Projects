#include <vector>
#include <string>
#include <fstream>
#include <sstream>
#include <iostream>
#include <algorithm>
#include "../include/Game.hpp"

const int NUM_OF_FEATURE_PLAYER = 3;
const int NUM_OF_FEATURE_ADMIN = 2;

using namespace std;

Game::Game(): player_logged_in(nullptr), admin_logged_in(nullptr){}

void Game::addPlayer(string _username, string _password, float _xp, bool is_from_file){
    if(is_from_file){//its for during the game
        Player* new_player = new Player(_username, _password, _xp);
        players.push_back(new_player);
        list_players_not_ready.push_back(new_player);
    }else{
        Player* new_player = new Player(_username, _password);
        players.push_back(new_player);
        list_players_not_ready.push_back(new_player);
        player_logged_in = new_player;
    }
}

void Game::addAdmin(string _username, string _password){
    Admin* new_admin = new Admin(_username, _password);
    admins.push_back(new_admin);
}

void Game::openReadCSVPlayers(string file_name){
    ifstream file(file_name);

    string line;
    getline(file, line);

    while(getline(file, line)){
        stringstream ss(line);
        string username;
        string password;
        float xp;
        string cell;

        for(int i=0; i<NUM_OF_FEATURE_PLAYER; i++){
            getline(ss, cell, ',');
            if(i==0) username = cell;
            if(i==1) password = cell;
            if(i==2) xp = stoi(cell);
        }

        addPlayer(username, password, xp, true);
    }
}

void Game::openReadCSVAdmins(string file_name){
    ifstream file(file_name);

    string line;
    getline(file, line);

    while(getline(file, line)){
        stringstream ss(line);
        string username;
        string password;
        string cell;

        for(int i=0; i<NUM_OF_FEATURE_ADMIN; i++){
            getline(ss, cell, ',');
            if(i==0) username = cell;
            if(i==1) password = cell;
        }

        addAdmin(username, password);
    }
}

bool Game::isUserNameForPlayer(string _username){
    bool is_username_for_player = false;
    for(Player* player: players){
        if(player->getUserName() == _username) is_username_for_player = true;
    }
    return is_username_for_player;
}

bool Game::isUserNameForAdmin(string _username){
    bool is_username_for_admin = false;
    for(Admin* admin: admins){
        if(admin->getUserName() == _username) is_username_for_admin = true;
    }
    return is_username_for_admin;
}

bool Game::isUserNameExist(string _username){
    bool is_username_exist = false;
    for(Player* player: players){
        if(player->getUserName() == _username) is_username_exist = true;
    }
    for(Admin* admin: admins){
        if(admin->getUserName() == _username) is_username_exist = true;
    }
    return is_username_exist;
}

bool Game::isPassWordCorrect(string _username, string _password){
    for(Player* player: players){
        if(player->getUserName() == _username){
            return player->isMyPassWord(_password);
        }
    }
    for(Admin* admin: admins){
        if(admin->getUserName() == _username){
            return admin->isMyPassWord(_password);
        }
    }
}

void Game::login(string _username){
    for(Player* player: players){
        if(player->getUserName() == _username){
            player_logged_in = player;
        }
    }
    for(Admin* admin: admins){
        if(admin->getUserName() == _username){
            admin_logged_in = admin;
        }
    }
}

void Game::logout(){
    player_logged_in = nullptr;
    admin_logged_in = nullptr;
}

void Game::setStatusReady(bool status){
    player_logged_in->ready_to_play = status;
    auto it_ready = find(list_players_ready.begin(), list_players_ready.end(), player_logged_in);
    if(it_ready != list_players_ready.end()){
        list_players_ready.erase(it_ready);
    }
    auto it_not_ready = find(list_players_not_ready.begin(), list_players_not_ready.end(), player_logged_in);
    if(it_not_ready != list_players_not_ready.end()){
        list_players_not_ready.erase(it_not_ready);
    }

    if(status){
        list_players_ready.push_back(player_logged_in);
    }else{
        list_players_not_ready.push_back(player_logged_in);
    }
}

bool Game::isReadyPlayerEmpty(){
    vector<Player*> list_players_ready_copy = list_players_ready;
    auto it_ready = find(list_players_ready_copy.begin(), list_players_ready_copy.end(), player_logged_in);
    if(it_ready != list_players_ready_copy.end()){
        list_players_ready_copy.erase(it_ready);
    }

    return list_players_ready_copy.size() == 0;
}

void Game::sortByXpAndUserName(vector<Player*>& players_ready, string sort_order){
    if(sort_order == "desc"){
        sort(players_ready.begin(), players_ready.end(), 
            [](Player* a, Player* b){
                if(a->getXp() != b->getXp()){
                    return a->getXp() > b->getXp();
                }
                return a->getUserName() < b->getUserName();
            });
    }
    if(sort_order == "asc"){
        sort(players_ready.begin(), players_ready.end(), 
            [](Player* a, Player* b){
                if(a->getXp() != b->getXp()){
                    return a->getXp() < b->getXp();
                }
                return a->getUserName() < b->getUserName();
            });
    }
}

void Game::printReadyPlayer(string sort_order){
    vector<Player*> list_players_ready_copy = list_players_ready;
    auto it_ready = find(list_players_ready_copy.begin(), list_players_ready_copy.end(), player_logged_in);
    if(it_ready != list_players_ready_copy.end()){
        list_players_ready_copy.erase(it_ready);
    }

    sortByXpAndUserName(list_players_ready_copy, sort_order);

    for(int i=0; i<list_players_ready_copy.size(); i++){
        cout << i+1 << ". " << list_players_ready_copy[i]->getUserName() << " with " << list_players_ready_copy[i]->getXp() << " XP" << endl;
    }
}

Player* Game::getPlayerByUserName(string _username){
    for(Player* player: players){
        if(player->getUserName() == _username) return player;
    }
    return nullptr;
}

void Game::setInvitation(string receiver_name, string game_type){
    int user_level_id = player_logged_in->getNewInvitationId();
    int app_level_id = invitations.size() + 1;
    string sender_name = player_logged_in->getUserName();
    if(game_type == "casual"){
        Invitation* new_invitation = new Invitation(receiver_name, sender_name, app_level_id, user_level_id, CASUAL);
        Player* sender = player_logged_in;
        Player* receiver = getPlayerByUserName(receiver_name);

        sender->addSentInvitation(new_invitation);
        receiver->addReceivedInvitation(new_invitation);
        invitations.push_back(new_invitation);
    }
    
}

Invitation* Game::getInvitationById(int id){
    for(Invitation* invitation: invitations){
        if(invitation->app_level_id == id) return invitation;
    }
    return nullptr;
}

void Game::setInvitationAccepted(int id){
    Invitation* target_invitation = getInvitationById(id);
    target_invitation->my_status = ACCEPTED;
}

void Game::setInvitationRejected(int id){
    Invitation* target_invitation = getInvitationById(id);
    target_invitation->my_status = REJECTED;
}

void Game::createNewGameAndAddPlayers(Player* player1, Player* player2, gamet game_type){
    if(game_type == CASUAL){
        Casual* new_casual = new Casual(player1, player2);
        player1->joinGame(new_casual);
        player2->joinGame(new_casual);
        casual_games.push_back(new_casual);
    }
    //continues
}

void Game::setReport(string reported_username, string reason){
    string sender_username = player_logged_in->getUserName();
    int app_level_id = reports.size() + 1;
    int user_level_id = player_logged_in->getNewReportId();
    Report* new_report = new Report(reason, reported_username, sender_username, app_level_id, user_level_id);
    player_logged_in->addSentReport(new_report);
    reports.push_back(new_report);
}

void Game::printProfile(string _username){
    Player* target_player = getPlayerByUserName(_username);
    cout << "username: " << '"' <<_username << '"' << endl;
    cout << "XP: " << target_player->getXp() << endl;
    cout << "Total wins: " << target_player->total_win << endl;
    cout << "Total losses: " << target_player->total_lose << endl;
}

bool Game::isReportsEmpty(){
    return reports.size() == 0;
}

void Game::printReports(){
    for(Report* report : reports){
        int id = report->app_level_id;
        string sender = '"' + report->sender_username + '"';
        string reported = '"' + report->reported_username + '"';
        string reason = '"' + report->reason + '"';
        cout << id << ": " << sender << " reported " << reported << " for: " << reason << endl;
    }
}