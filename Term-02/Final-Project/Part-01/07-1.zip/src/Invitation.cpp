#include "../include/Invitation.hpp"

Invitation::Invitation(string _receiver, string _sender, int _app_level_id, int _user_level_id, gamet _game_type): receiver(_receiver)
                    , sender(_sender), game_type(_game_type)
                    , my_status(PENDING), app_level_id(_app_level_id), user_level_id(_user_level_id){}

string Invitation::get_sender_name(){ return sender; }

gamet Invitation::get_game_type(){ return game_type; }
