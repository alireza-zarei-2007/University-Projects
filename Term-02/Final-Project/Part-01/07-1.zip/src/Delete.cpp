#include "../include/Delete.hpp"

const string OK = "OK";
const string EMPTY = "Empty";
const string NOT_FOUND = "Not Found";
const string BAD_REQUEST = "Bad Request";
const string PERMISSION_DENIED = "Permission Denied";

Delete::Delete(vector<string> _commnads_noun, string _command_verb): Command(_commnads_noun, _command_verb){}