#include <iostream>
#include <vector>
#include <string>
#include "../include/Game.hpp"
#include "../include/CommandHandler.hpp"

using namespace std;

int main(int argc, char* argv[]) {
    if(argc != 3){
        cerr << "Exactly two arguments must be entered !" << endl;
        return 1;
    }

    const string PLAYERS_DATA_FILE_NAME = argv[1];
    const string ADMINS_DATA_FILE_NAME = argv[2];

    Game game;
    CommandHandler handler(game);

    game.openReadCSVPlayers(PLAYERS_DATA_FILE_NAME);
    game.openReadCSVAdmins(ADMINS_DATA_FILE_NAME);

    handler.run();

    return 0;
}