#include "../include/Command.hpp"

Command::Command(vector<string> _commnads_noun, string _command_verb): commnads_noun(_commnads_noun), command_verb(_command_verb){}