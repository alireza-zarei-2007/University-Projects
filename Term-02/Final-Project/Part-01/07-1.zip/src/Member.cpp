#include "../include/Member.hpp"

Member::Member(string _username, string _password): username(_username), password(_password){}

string Member::getUserName(){ return username; }

bool Member::isMyPassWord(string _password){
    return password == _password;
}