#include "../include/Get.hpp"
#include <iostream>

const string OK = "OK";
const string EMPTY = "Empty";
const string NOT_FOUND = "Not Found";
const string BAD_REQUEST = "Bad Request";
const string PERMISSION_DENIED = "Permission Denied";

const string ASC = "asc";
const string DESC = "desc";

Get::Get(vector<string> _commnads_noun, string _command_verb): Command(_commnads_noun, _command_verb){}

bool Get::generalCheckSyn(string _arguments){
    string word_key;
    string word_value;
    stringstream ss(_arguments);
    while(ss >> word_key){
        if(isCommandSynTrue(word_key)){
            return false;
        }
        if(ss >> word_value){
            if(!isCommandSynTrue(word_value)){
                return false;
            }
        }else{
            return false;
        }
    }
    return true;
}

bool Get::isMyCommandNoun(string cmd_noun){
    bool is_my_command_noun = false;
    for(string noun: commnads_noun){
        if(cmd_noun == noun){
            is_my_command_noun = true;
        }
    }
    return is_my_command_noun;
}

bool Get::isCommandSynTrue(string word){
    if(word.front() == '"' && word.back() == '"' && word.length() >= 2){
        return true;
    }
    return false;
}

bool Get::isSortOrderSynTrue(string& sort_order, string word){
    word = word.substr(1, word.length() - 2);
    if(word == ASC){
        sort_order = ASC;
        return true;
    }else if(word == DESC){
        sort_order = DESC;
        return true;
    }else{
        return false;
    }
}


void Get::checkArgumentsCMOpponentsAndProcess(Game& game, string _arguments){
    string sort_order = DESC;
    string word_key;
    string word_value;
    bool is_sort_order_writed = false;
    bool is_command_syn_true = false;
    bool is_sort_order_syn_true = false;

    stringstream ss(_arguments);
    while(ss >> word_key){
        if(word_key == "sort_order"){
            is_sort_order_writed = true;
            if(ss >> word_value){
                is_command_syn_true = isCommandSynTrue(word_value);
                if(is_command_syn_true){
                    is_sort_order_syn_true = isSortOrderSynTrue(sort_order, word_value);
                }
            }
        }
        if(is_sort_order_writed && is_command_syn_true && is_sort_order_syn_true){
            break;
        }
    }

    if(!generalCheckSyn(_arguments)){
        cout << BAD_REQUEST << endl;
        return;
    }

    if(is_sort_order_writed && !is_command_syn_true){
        cout << BAD_REQUEST << endl;
        return;
    }

    if((game.admin_logged_in != nullptr) || (game.admin_logged_in == nullptr && game.player_logged_in == nullptr)){
        cout << PERMISSION_DENIED << endl;
        return;
    }

    if(is_sort_order_writed && !is_sort_order_syn_true){
        cout << BAD_REQUEST << endl;
        return;
    }

    if(game.isReadyPlayerEmpty()){
        cout << EMPTY << endl;
        return;
    }

    game.printReadyPlayer(sort_order);
}

void Get::checkArgumentsMatchStatusAndProcess(Game& game, string _arguments){
    if(!generalCheckSyn(_arguments)){
        cout << BAD_REQUEST << endl;
        return;
    }

    if((game.admin_logged_in != nullptr) || (game.admin_logged_in == nullptr && game.player_logged_in == nullptr)){
        cout << PERMISSION_DENIED << endl;
        return;
    }

    if(!game.player_logged_in->is_playing){
        cout << NOT_FOUND << endl;
        return;
    }

    if(game.player_logged_in->get_current_game_casual() != nullptr){
        Casual* current_game = game.player_logged_in->get_current_game_casual();
        current_game->printMatchStatus(game.player_logged_in);
        return;
    }
}

void Get::setValueOnObject(string& object, string word){
    word = word.substr(1, word.length() - 2);
    object = word;
}

void Get::checkArgumentsProfileAndProcess(Game& game, string _arguments){
    string username_value;
    string word_key;
    string word_value;
    bool is_username_exist = false;

    if(!generalCheckSyn(_arguments)){
        cout << BAD_REQUEST << endl;
        return;
    }

    stringstream ss(_arguments);
    
    while(ss >> word_key){
        if(word_key == "username"){
            ss >> word_value;
            setValueOnObject(username_value, word_value);
            is_username_exist = true;
        }
    }
    
    if(game.admin_logged_in == nullptr && game.player_logged_in == nullptr){
        cout << PERMISSION_DENIED << endl;
        return;
    }

    if((!is_username_exist) && (game.admin_logged_in != nullptr)){
        cout << PERMISSION_DENIED << endl;
        return;
    }

    if(!is_username_exist){
        username_value = game.player_logged_in->getUserName();
    }

    if(!game.isUserNameExist(username_value)){
        cout << NOT_FOUND << endl;
        return;
    }

    if(game.isUserNameForAdmin(username_value)){
        cout << PERMISSION_DENIED << endl;
        return;
    }
    
    game.printProfile(username_value);
    
}

void Get::checkArgumentsPrintInvitationsAndProcess(Game& game, string _arguments){
    if(!generalCheckSyn(_arguments)){
        cout << BAD_REQUEST << endl;
        return;
    }

    if((game.admin_logged_in != nullptr) || (game.admin_logged_in == nullptr && game.player_logged_in == nullptr)){
        cout << PERMISSION_DENIED << endl;
        return;
    }

    if(game.player_logged_in->isReceivedInvitationsEmpty()){
        cout << EMPTY << endl;
        return;
    }

    game.player_logged_in->printReceivedInvitations();
}

void Get::checkArgumentsPrintReportsAndProcess(Game& game, string _arguments){
    if(!generalCheckSyn(_arguments)){
        cout << BAD_REQUEST << endl;
        return;
    }

    if((game.player_logged_in != nullptr) || (game.admin_logged_in == nullptr && game.player_logged_in == nullptr)){
        cout << PERMISSION_DENIED << endl;
        return;
    }

    if(game.isReportsEmpty()){
        cout << EMPTY << endl;
        return;
    }

    game.printReports();
}