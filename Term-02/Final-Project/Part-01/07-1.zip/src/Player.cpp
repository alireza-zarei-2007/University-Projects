#include "../include/Player.hpp"

Player::Player(string _username, string _password): Member(_username, _password), xp(500.0), total_win(0), total_lose(0),  ready_to_play(false)
                                                , is_playing(false), current_game_casual(nullptr){}

Player::Player(string _username, string _password, float _xp): Member(_username, _password), xp(_xp), total_win(0), total_lose(0), ready_to_play(false)
                                                        , is_playing(false), current_game_casual(nullptr){}

int Player::getXp(){ return xp; }

int Player::getNewInvitationId(){ return sent_invitations.size() + 1; }

void Player::addReceivedInvitation(Invitation* new_invitation){
    received_invitations.push_back(new_invitation);
}

void Player::addSentInvitation(Invitation* new_invitation){
    sent_invitations.push_back(new_invitation);
}

bool Player::isReceivedInvitationExistAndPending(int invite_id){
    for(Invitation* invitation: received_invitations){
        if(invitation->app_level_id == invite_id && invitation->my_status == PENDING){
            return true;
        }
    }
    return false;
}

void Player::joinGame(Casual* game){
    current_game_casual = game;
    is_playing = true;
}

Casual* Player::get_current_game_casual(){ return current_game_casual; }

void Player::changeXpAfterGame(float delta_xp){
    xp += delta_xp;
}

void Player::casualGameEnded(){
    current_game_casual = nullptr;
}

int Player::getNewReportId(){ return sent_reports.size() + 1; }

void Player::addSentReport(Report* new_report){
    sent_reports.push_back(new_report);
}

bool Player::isReceivedInvitationsEmpty(){
    for(Invitation* invitation: received_invitations){
        if(invitation->my_status == PENDING){
            return false;
        }
    }
    return true;
}

void Player::printReceivedInvitations(){
    for(Invitation* invitation : received_invitations){
        if(invitation->my_status == PENDING){
            cout << invitation->app_level_id << ": Invitation from " << '"' 
            << invitation->get_sender_name() << '"' << " for a " << "\"casual\"" << " match" << endl;
        }
    }
}