#include "../include/Post.hpp"

const string OK = "OK";
const string EMPTY = "Empty";
const string NOT_FOUND = "Not Found";
const string BAD_REQUEST = "Bad Request";
const string PERMISSION_DENIED = "Permission Denied";

const string USERNAME = "username";

Post::Post(vector<string> _commnads_noun, string _command_verb): Command(_commnads_noun, _command_verb){}

bool Post::generalCheckSyn(string _arguments){
    string word_key;
    string word_value;
    stringstream ss(_arguments);
    while(ss >> word_key){
        if(isCommandSynTrue(word_key)){
            return false;
        }
        if(ss >> word_value){
            if(!isCommandSynTrue(word_value)){
                return false;
            }
        }else{
            return false;
        }
    }
    return true;
}

bool Post::isMyCommandNoun(string cmd_noun){
    bool is_my_command_noun = false;
    for(string noun: commnads_noun){
        if(cmd_noun == noun){
            is_my_command_noun = true;
        }
    }
    return is_my_command_noun;
}

bool Post::isCommandSynTrue(string word){
    if(word.front() == '"' && word.back() == '"' && word.length() >= 2){
        return true;
    }
    return false;
}

bool Post::isUserNameFind(string& username, string word){
    if(word.front() == '"' && word.back() == '"' && word.length() >= 2){
        word = word.substr(1, word.length() - 2);
        username = word;
        return true;
    }
    return false;
}

bool Post::isPassWordFind(string& password, string word){
    if(word.front() == '"' && word.back() == '"' && word.length() >= 2){
        word = word.substr(1, word.length() - 2);
        password = word;
        return true;
    }
    return false;
}

void Post::checkArgumentsRegisterAndProcess(Game& game, string _arguments){
    string username;
    string password;
    bool is_username_find = false;
    bool is_password_find = false;
    string word_key;
    string word_value;

    stringstream ss(_arguments);
    while(ss >> word_key){
        if(word_key == USERNAME){
            if(ss >> word_value){
                is_username_find = isUserNameFind(username, word_value);
            }
        }else if(word_key == "password"){
            if(ss >> word_value){
                is_password_find = isPassWordFind(password, word_value);
            }
        }
        if(is_username_find && is_password_find) break;
    }

    if(!generalCheckSyn(_arguments)){
        cout << BAD_REQUEST << endl;
        return;
    }
    
    if(!is_username_find || !is_password_find){
        cout << BAD_REQUEST << endl;
        return;
    }
    if(game.admin_logged_in != nullptr || game.player_logged_in != nullptr){
        cout << PERMISSION_DENIED << endl;
        return;
    }
    if(game.isUserNameExist(username)){
        cout << BAD_REQUEST << endl;
        return;
    }

    game.addPlayer(username, password, 0, false);
    cout << OK << endl;
}

void Post::checkArgumentsLoginAndProcess(Game& game, string _arguments){
    string username;
    string password;
    bool is_username_find = false;
    bool is_password_find = false;
    string word_key;
    string word_value;

    stringstream ss(_arguments);
    while(ss >> word_key){
        if(word_key == USERNAME){
            if(ss >> word_value){
                is_username_find = isUserNameFind(username, word_value);
            }
        }else if(word_key == "password"){
            if(ss >> word_value){
                is_password_find = isPassWordFind(password, word_value);
            }
        }
        if(is_username_find && is_password_find) break;
    }

    if(!generalCheckSyn(_arguments)){
        cout << BAD_REQUEST << endl;
        return;
    }

    if(!is_username_find || !is_password_find){
        cout << BAD_REQUEST << endl;
        return;
    }

    if(game.admin_logged_in != nullptr || game.player_logged_in != nullptr){
        cout << PERMISSION_DENIED << endl;
        return;
    }

    if(!game.isUserNameExist(username)){
        cout << NOT_FOUND << endl;
        return;
    }

    if(!game.isPassWordCorrect(username, password)){
        cout << PERMISSION_DENIED << endl;
        return;
    }

    game.login(username);
    cout << OK << endl;
}

void Post::checkArgumentsLogOutAndProcess(Game& game, string _arguments){
    if(!generalCheckSyn(_arguments)){
        cout << BAD_REQUEST << endl;
        return;
    }

    if(game.admin_logged_in == nullptr && game.player_logged_in == nullptr){
        cout << PERMISSION_DENIED << endl;
        return;
    }

    game.logout();
    cout << OK << endl;
}

bool Post::isStatusSynTrue(bool& status, string word){
    word = word.substr(1, word.length() - 2);
    if(word == "true"){
        status = true;
        return true;
    }else if(word == "false"){
        status = false;
        return true;
    }else{
        return false;
    }
}

void Post::checkArgumentsCMReadyAndProcess(Game& game, string _arguments){
    bool status;
    string word_key;
    string word_value;
    bool is_status_syn_true = false;
    bool is_command_syn_true = false;

    stringstream ss(_arguments);
    while(ss >> word_key){
        if(word_key == "status"){
            if(ss >> word_value){
                is_command_syn_true = isCommandSynTrue(word_value);
                if(is_command_syn_true){
                    is_status_syn_true = isStatusSynTrue(status, word_value);
                }
            }
        }
        if(is_status_syn_true) break;
    }

    if(!generalCheckSyn(_arguments)){
        cout << BAD_REQUEST << endl;
        return;
    }

    if(!is_command_syn_true){
        cout << BAD_REQUEST << endl;
        return;
    }

    if((game.admin_logged_in != nullptr) || (game.admin_logged_in == nullptr && game.player_logged_in == nullptr)){
        cout << PERMISSION_DENIED << endl;
        return;
    }

    if(!is_status_syn_true){
        cout << BAD_REQUEST << endl;
        return;
    }

    game.setStatusReady(status);
    cout << OK << endl;

}

void Post::setValueOnObject(string& object, string word){
    word = word.substr(1, word.length() - 2);
    object = word;
}

void Post::checkArgumentsInviteAndProcess(Game& game, string _arguments){
    string username;
    string match_type;
    bool is_username_find = false;
    bool is_matchtype_find = false;
    bool is_command_syn_true1 = false;
    bool is_command_syn_true2 = false;
    string word_key;
    string word_value;

    stringstream ss1(_arguments);
    stringstream ss2(_arguments);
    while(ss1 >> word_key){
        if(word_key == USERNAME){
            if(ss1 >> word_value){
                is_command_syn_true1 = isCommandSynTrue(word_value);
                if(is_command_syn_true1){
                    setValueOnObject(username, word_value);
                }
            }
        }
    }
    while(ss2 >> word_key){
        if(word_key == "match_type"){
            if(ss2 >> word_value){
                is_command_syn_true2 = isCommandSynTrue(word_value);
                if(is_command_syn_true2){
                    setValueOnObject(match_type, word_value);
                }
            }
        }
    }

    if(!generalCheckSyn(_arguments)){
        cout << BAD_REQUEST << endl;
        return;
    }

    if(!is_command_syn_true1 || !is_command_syn_true2){
        cout << BAD_REQUEST << endl;
        return;
    }

    if((game.admin_logged_in != nullptr) || (game.admin_logged_in == nullptr && game.player_logged_in == nullptr)){
        cout << PERMISSION_DENIED << endl;
        return;
    }

    if(username == game.player_logged_in->getUserName()){
        cout << NOT_FOUND << endl;
        return;
    }

    if(game.isUserNameForAdmin(username)){
        cout << PERMISSION_DENIED << endl;
        return;
    }

    if(!game.isUserNameForPlayer(username)){
        cout << NOT_FOUND << endl;
        return;
    }

    if(match_type != "casual"){
        cout << BAD_REQUEST << endl;
        return;
    }

    game.setInvitation(username, match_type);
    cout << OK << endl;
}

void Post::checkArgumentsRejInviteAndProcess(Game& game, string _arguments){
    int invite_id;
    string invite_id_str;
    string word_key;
    string word_value;
    bool is_command_syn_true = false;

    stringstream ss(_arguments);
    while(ss >> word_key){
        if(word_key == "invitation_id"){
            if(ss >> word_value){
                is_command_syn_true = isCommandSynTrue(word_value);
                if(is_command_syn_true) setValueOnObject(invite_id_str, word_value);
            }
        }
    }

    if(!generalCheckSyn(_arguments)){
        cout << BAD_REQUEST << endl;
        return;
    }

    if(!is_command_syn_true){
        cout << BAD_REQUEST << endl;
        return;
    }

    if((game.admin_logged_in != nullptr) || (game.admin_logged_in == nullptr && game.player_logged_in == nullptr)){
        cout << PERMISSION_DENIED << endl;
        return;
    }

    invite_id = stoi(invite_id_str);
    if(!game.player_logged_in->isReceivedInvitationExistAndPending(invite_id)){
        cout << NOT_FOUND << endl;
        return;
    }

    game.setInvitationRejected(invite_id);
    cout << OK << endl;

}

void Post::checkArgumentsStartMatchAndProcess(Game& game, string _arguments){
    int invite_id;
    string invite_id_str;
    string word_key;
    string word_value;
    bool is_command_syn_true = false;

    stringstream ss(_arguments);
    while(ss >> word_key){
        if(word_key == "invitation_id"){
            if(ss >> word_value){
                is_command_syn_true = isCommandSynTrue(word_value);
                if(is_command_syn_true) setValueOnObject(invite_id_str, word_value);
            }
        }
    }

    if(!generalCheckSyn(_arguments)){
        cout << BAD_REQUEST << endl;
        return;
    }

    if(!is_command_syn_true){
        cout << BAD_REQUEST << endl;
        return;
    }

    if((game.admin_logged_in != nullptr) || (game.admin_logged_in == nullptr && game.player_logged_in == nullptr)){
        cout << PERMISSION_DENIED << endl;
        return;
    }

    invite_id = stoi(invite_id_str);
    if(!game.player_logged_in->isReceivedInvitationExistAndPending(invite_id)){
        cout << NOT_FOUND << endl;
        return;
    }

    
    string sender_name = game.getInvitationById(invite_id)->get_sender_name();
    Player* sender = game.getPlayerByUserName(sender_name);
    if(game.player_logged_in->is_playing || sender->is_playing){
        cout << PERMISSION_DENIED << endl;
        return;
    }

    game.setInvitationAccepted(invite_id);
    gamet game_type = game.getInvitationById(invite_id)->get_game_type();
    game.createNewGameAndAddPlayers(game.player_logged_in, sender, game_type);
    cout << OK << endl; 
}

bool Post::isActionSynTrue(string word){
    return word == SHOOT || word == DEFEND || word == RELOAD;
}

void Post::checkArgumentsActionAndProcess(Game& game, string _arguments){
    string action;
    string word_key;
    string word_value;
    bool is_action_syn_true = false;
    bool is_command_syn_true = false;

    stringstream ss(_arguments);
    while(ss >> word_key){
        if(word_key == "action"){
            if(ss >> word_value){
                is_command_syn_true = isCommandSynTrue(word_value);
                if(is_command_syn_true){
                    setValueOnObject(action, word_value);
                    if(isActionSynTrue(action)) is_action_syn_true = true;
                }
            }
        }
    }

    if(!generalCheckSyn(_arguments)){
        cout << BAD_REQUEST << endl;
        return;
    }

    if(!is_command_syn_true){
        cout << BAD_REQUEST << endl;
        return;
    }

    if((game.admin_logged_in != nullptr) || (game.admin_logged_in == nullptr && game.player_logged_in == nullptr)){
        cout << PERMISSION_DENIED << endl;
        return;
    }

    if(!is_action_syn_true){
        cout << BAD_REQUEST << endl;
        return;
    }

    if(!game.player_logged_in->is_playing){
        cout << NOT_FOUND << endl;
        return;
    }
    
    if(game.player_logged_in->get_current_game_casual() != nullptr){
        Casual* current_game = game.player_logged_in->get_current_game_casual();
        if(current_game->canPlayerMove(game.player_logged_in)){
            if(action == SHOOT && !current_game->hasEnoughBullets(game.player_logged_in)){
                cout << BAD_REQUEST << endl;
                return;
            }else{
                current_game->processAction(game.player_logged_in, action);
                cout << OK << endl;
                return;
            }
        }else{
            cout << PERMISSION_DENIED << endl;
            return;
        }
    }
}

void Post::checkArgumentsReportAndProcess(Game& game, string _arguments){
    string username_value;
    string reason_value;
    bool is_user_key_exist = false;
    bool is_reaon_key_exist = false;
    string word_key;
    string word_value;
    string none;
    string main_argument = _arguments;

    stringstream ss1(_arguments);
    while (ss1 >> word_key){
        if(word_key == "reason") is_reaon_key_exist = true;
        if(word_key == USERNAME) is_user_key_exist = true;
    }
    
    if(!is_reaon_key_exist || !is_user_key_exist){
        cout << BAD_REQUEST << endl;
        return;
    }

    size_t reason_pos = _arguments.find("reason");

    size_t reason_value_start = _arguments.find('"', reason_pos);
    if(reason_value_start == string::npos){
        cout << BAD_REQUEST << endl;
        return;
    }
    size_t reason_value_end = _arguments.find('"', reason_value_start + 1);
    if(reason_value_end == string::npos){
        cout << BAD_REQUEST << endl;
        return;
    }

    string reason_key_and_value = _arguments.substr(reason_pos, reason_value_end - reason_pos + 1);
    _arguments.erase(reason_pos, reason_value_end - reason_pos + 1);

    if(!generalCheckSyn(_arguments)){
        cout << BAD_REQUEST << endl;
        return;
    }

    stringstream ss2(reason_key_and_value);
    ss2 >> none;
    if(ss2 >> none){
        if(none[0] != '"'){
            cout << BAD_REQUEST << endl;
            return;
        }
    }

    reason_value = main_argument.substr(reason_value_start+1, reason_value_end - reason_value_start - 1);

    stringstream ss3(main_argument);
    while(ss3 >> word_key){
        if(word_key == USERNAME){
            if(ss3 >> word_value){
                setValueOnObject(username_value, word_value);
            }
        }
    }

    if((game.admin_logged_in != nullptr) || (game.admin_logged_in == nullptr && game.player_logged_in == nullptr)){
        cout << PERMISSION_DENIED << endl;
        return;
    }

    if(username_value == game.player_logged_in->getUserName()){
        cout << NOT_FOUND << endl;
        return;
    }

    if(!game.isUserNameForPlayer(username_value)){
        cout << NOT_FOUND << endl;
        return;
    }

    if(game.isUserNameForAdmin(username_value)){
        cout << PERMISSION_DENIED << endl;
        return;
    }

    if(isBlank(reason_value)){
        cout << BAD_REQUEST << endl;
        return;
    }

    game.setReport(username_value, reason_value);
    cout << OK << endl;
    return;
}

bool Post::isBlank(string line){
    for(char c : line){
        if(!isspace(c)) return false;
    }
    return true;
}