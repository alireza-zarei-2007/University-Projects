#include "../include/Report.hpp"

Report::Report(string _reason, string _reported_username, string _sender_username, int _app_level_id, int _user_level_id):reason(_reason)
            , reported_username(_reported_username), sender_username(_sender_username), app_level_id(_app_level_id)
            , user_level_id(_user_level_id) {}