#include "../include/Admin.hpp"

Admin::Admin(string _username, string _password): Member(_username, _password){}